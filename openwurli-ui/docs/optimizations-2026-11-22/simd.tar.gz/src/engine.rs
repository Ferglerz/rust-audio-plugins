//! WurliEngine — synth engine extracted from `openwurli-plugin`.
//!
//! Owns voice management (slots, allocation, stealing, sustain pedal)
//! and the shared signal chain (preamp → fixed circuit drive → power amp
//! → speaker, output at the amp-rail reference). Framework-agnostic so any host
//! (nih-plug, custom DAW integrations, other library hosts) can wrap it without
//! copying voice or signal-chain code.
//!
//! Smoothing model: the three audio-rate user params (volume, tremolo
//! depth, speaker character) ramp internally over `SMOOTH_SAMPLES_AT_44K1`
//! base-rate samples after each setter call to avoid zipper noise on knob
//! moves. Hosts can call setters at block rate without their own smoothers.
//! Block-rate params (MLP, noise) take effect immediately.

#[cfg(not(feature = "runtime-models"))]
use crate::dk_preamp::DkPreamp;
use crate::oversampler::Oversampler;
#[cfg(not(feature = "runtime-models"))]
use crate::power_amp::PowerAmp;
use crate::preamp::PreampModel;
use crate::speaker::Speaker;
use crate::tables;
use crate::tremolo::Tremolo;
use crate::voice::{Voice, VoiceCharacter};

const MAX_VOICES: usize = 64;
const MAX_BLOCK_SIZE: usize = 8192;

/// Voice slot lifecycle. Public for engine introspection from tests and
/// debug tooling; not part of the realtime API surface — hosts shouldn't
/// need to read this in `process()`.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum VoiceState {
    Free,
    Held,
    /// Key released while sustain pedal was down — reed rings undamped.
    Sustained,
    Releasing,
}

struct VoiceSlot {
    voice: Option<Voice>,
    state: VoiceState,
    midi_note: u8,
    age: u64,
    /// Voice being faded out from stealing (5 ms linear crossfade).
    steal_voice: Option<Voice>,
    steal_fade: u32,
    steal_fade_len: u32,
}

impl Default for VoiceSlot {
    fn default() -> Self {
        Self {
            voice: None,
            state: VoiceState::Free,
            midi_note: 0,
            age: 0,
            steal_voice: None,
            steal_fade: 0,
            steal_fade_len: 0,
        }
    }
}

/// Single-pole linear smoother: given a target value, produces a per-sample
/// ramp toward it over `samples` base-rate samples. Used for vol, tremolo
/// depth, speaker character so block-rate setter calls don't zipper.
struct LinearSmoother {
    current: f64,
    target: f64,
    step: f64,
    samples_remaining: u32,
    ramp_samples: u32,
}

impl LinearSmoother {
    fn new(initial: f64, ramp_samples: u32) -> Self {
        Self {
            current: initial,
            target: initial,
            step: 0.0,
            samples_remaining: 0,
            ramp_samples,
        }
    }

    fn set_target(&mut self, target: f64) {
        if (target - self.target).abs() < 1e-9 {
            return;
        }
        self.target = target;
        let delta = target - self.current;
        if self.ramp_samples == 0 {
            self.current = target;
            self.samples_remaining = 0;
            return;
        }
        self.step = delta / self.ramp_samples as f64;
        self.samples_remaining = self.ramp_samples;
    }

    /// Snap to value instantly (no ramp). Used on `reset()` and
    /// `set_sample_rate()` to avoid carrying a stale ramp across.
    fn snap_to(&mut self, value: f64) {
        self.current = value;
        self.target = value;
        self.step = 0.0;
        self.samples_remaining = 0;
    }

    fn set_ramp_samples(&mut self, ramp_samples: u32) {
        self.ramp_samples = ramp_samples;
        // Recompute step for any in-flight ramp so it still finishes correctly.
        if self.samples_remaining > 0 {
            self.step = (self.target - self.current) / ramp_samples.max(1) as f64;
            self.samples_remaining = ramp_samples;
        }
    }

    #[inline]
    fn next(&mut self) -> f64 {
        if self.samples_remaining > 0 {
            self.current += self.step;
            self.samples_remaining -= 1;
            if self.samples_remaining == 0 {
                self.current = self.target;
            }
        }
        self.current
    }
}

/// Circuit pair selected at runtime. Both modes share voices and MIDI state.
#[cfg(feature = "runtime-models")]
#[derive(Clone, Copy, Debug, Default, PartialEq, Eq)]
pub enum CircuitMode {
    #[default]
    Fast,
    Heavy,
}

#[cfg(feature = "runtime-models")]
impl CircuitMode {
    fn weight(self) -> f64 {
        match self {
            Self::Fast => 0.0,
            Self::Heavy => 1.0,
        }
    }
}

#[cfg(feature = "runtime-models")]
trait RuntimeAmp {
    fn process(&mut self, input: f64) -> f64;
    fn reset(&mut self);
}

#[cfg(feature = "runtime-models")]
macro_rules! runtime_amp {
    ($ty:ty) => {
        impl RuntimeAmp for $ty {
            fn process(&mut self, input: f64) -> f64 {
                <$ty>::process(self, input)
            }
            fn reset(&mut self) {
                <$ty>::reset(self)
            }
        }
    };
}
#[cfg(feature = "runtime-models")]
runtime_amp!(crate::power_amp::FastPowerAmp);
#[cfg(feature = "runtime-models")]
runtime_amp!(crate::power_amp::HeavyPowerAmp);

/// Per-model circuit history. Oscillators, MIDI and parameter clocks live in
/// WurliEngine; no second voice bank is rendered while a model is hidden.
#[cfg(feature = "runtime-models")]
struct CircuitChain<P, A> {
    preamp: P,
    amp: A,
    c9_state: f64,
    oversampler: Oversampler,
    speaker: Speaker,
    up: Vec<f64>,
    out: Vec<f64>,
    #[cfg(test)]
    drive_peak: f64,
    #[cfg(test)]
    drive_sumsq: f64,
    #[cfg(test)]
    drive_n: u64,
}

#[cfg(feature = "runtime-models")]
impl<P: PreampModel, A: RuntimeAmp> CircuitChain<P, A> {
    fn new(preamp: P, amp: A, sample_rate: f64) -> Self {
        Self {
            preamp,
            amp,
            c9_state: 0.0,
            oversampler: Oversampler::new(),
            speaker: Speaker::new(sample_rate),
            up: vec![0.0; MAX_BLOCK_SIZE * 2],
            out: vec![0.0; MAX_BLOCK_SIZE],
            #[cfg(test)]
            drive_peak: 0.0,
            #[cfg(test)]
            drive_sumsq: 0.0,
            #[cfg(test)]
            drive_n: 0,
        }
    }

    fn ensure_buffer_capacity(&mut self, len: usize) {
        if self.out.len() < len {
            self.out.resize(len, 0.0);
            self.up.resize(len * 2, 0.0);
        }
    }

    fn reset(&mut self) {
        self.preamp.reset();
        self.c9_state = 0.0;
        self.amp.reset();
        self.oversampler.reset();
        self.speaker.reset();
    }

    fn process_bus(
        &mut self,
        input: &[f64],
        ldr: &[f64],
        gain: &[f64],
        alpha: &[f64],
        oversample: bool,
    ) {
        let len = input.len();
        if oversample {
            self.oversampler.upsample_2x(input, &mut self.up[..len * 2]);
        }
        let count = if oversample { len * 2 } else { len };
        for i in 0..count {
            self.preamp.set_ldr_resistance(ldr[i]);
            let signal = if oversample { self.up[i] } else { input[i] };
            let base = if oversample { i / 2 } else { i };
            let preamp_out = self.preamp.process_sample(signal);
            let drive_gain = self.preamp.open_circuit_output_factor() * gain[base];
            self.c9_state += alpha[base] * (preamp_out * drive_gain - self.c9_state);
            let drive = self.c9_state;
            #[cfg(test)]
            {
                self.drive_peak = self.drive_peak.max(drive.abs());
                self.drive_sumsq += drive * drive;
                self.drive_n += 1;
            }
            let value = self.amp.process(drive);
            if oversample {
                self.up[i] = value;
            } else {
                self.out[i] = value;
            }
        }
        if oversample {
            self.oversampler
                .downsample_2x(&self.up[..len * 2], &mut self.out[..len]);
        }
    }

    fn shape(&mut self, index: usize, character: f64) -> f64 {
        self.speaker.set_character(character);
        self.speaker.process(self.out[index])
    }
}

#[cfg(feature = "runtime-models")]
struct RuntimeCircuits {
    fast: CircuitChain<crate::dk_preamp::FastPreamp, crate::power_amp::FastPowerAmp>,
    heavy: CircuitChain<crate::dk_preamp::HeavyPreamp, crate::power_amp::HeavyPowerAmp>,
    ldr: Vec<f64>,
    gain: Vec<f64>,
    alpha: Vec<f64>,
    mode: CircuitMode,
    mix: LinearSmoother,
    preroll_samples: u32,
    preroll_remaining: u32,
}

#[cfg(feature = "runtime-models")]
impl RuntimeCircuits {
    fn new(sample_rate: f64, os_rate: f64, mode: CircuitMode) -> Self {
        Self {
            fast: CircuitChain::new(
                crate::dk_preamp::FastPreamp::new(os_rate),
                crate::power_amp::FastPowerAmp::new_at_sample_rate(os_rate),
                sample_rate,
            ),
            heavy: CircuitChain::new(
                crate::dk_preamp::HeavyPreamp::new(os_rate),
                crate::power_amp::HeavyPowerAmp::new_at_sample_rate(os_rate),
                sample_rate,
            ),
            ldr: vec![0.0; MAX_BLOCK_SIZE * 2],
            gain: vec![0.0; MAX_BLOCK_SIZE],
            alpha: vec![0.0; MAX_BLOCK_SIZE],
            mode,
            mix: LinearSmoother::new(mode.weight(), (sample_rate * 0.020).round().max(1.0) as u32),
            preroll_samples: (sample_rate * 0.100).round().max(1.0) as u32,
            preroll_remaining: 0,
        }
    }

    fn ensure_buffer_capacity(&mut self, len: usize) {
        self.fast.ensure_buffer_capacity(len);
        self.heavy.ensure_buffer_capacity(len);
        if self.ldr.len() < len * 2 {
            self.ldr.resize(len * 2, 0.0);
            self.gain.resize(len, 0.0);
            self.alpha.resize(len, 0.0);
        }
    }

    fn reset(&mut self) {
        self.fast.reset();
        self.heavy.reset();
        self.preroll_remaining = 0;
        self.mix.snap_to(self.mode.weight());
    }

    fn running(&self, warming: bool) -> (bool, bool) {
        if warming || self.preroll_remaining > 0 || self.mix.samples_remaining > 0 {
            (true, true)
        } else {
            (
                self.mode == CircuitMode::Fast,
                self.mode == CircuitMode::Heavy,
            )
        }
    }
}

/// Wurlitzer 200A synth engine — owns voices, signal chain, and all
/// params except the host-facing parameter container.
///
/// Host integration sketch:
/// ```ignore
/// let mut engine = WurliEngine::new(sample_rate);
/// // Per buffer:
/// engine.set_volume(params.volume.value() as f64);
/// engine.set_tremolo_depth(params.tremolo_depth.value() as f64);
/// engine.set_speaker_character(params.speaker.value() as f64);
/// engine.set_mlp_enabled(params.mlp.value());
/// // Circuit noise exists only in the opt-in melange preamp (no-op otherwise):
/// // engine.set_noise_enabled(on); engine.set_noise_gain(gain);
/// for event in midi_events {
///     match event {
///         NoteOn(n, v) => engine.note_on(n, v),
///         NoteOff(n)   => engine.note_off(n),
///         Sustain(on)  => engine.set_sustain(on),
///     }
/// }
/// engine.render(&mut mono_out_buffer);
/// ```
pub struct WurliEngine {
    voices: Vec<VoiceSlot>,
    age_counter: u64,

    // Shared signal chain (mono, post voice-sum)
    #[cfg(not(feature = "runtime-models"))]
    preamp: DkPreamp,
    /// R-11 "Reed Bar Trim" [Ω], the per-unit factory trimmer ahead of the
    /// volume pot (see tables::R11_REED_BAR_VOLUME_DEFAULT). Smoothed so a
    /// host sweep does not step the drive.
    reed_bar_trim: LinearSmoother,
    /// C-9 pole at the amp input (volume network, see tables::volume_pot_pole_hz):
    /// one-pole lowpass state and its coefficient, refreshed per base-rate sample.
    #[cfg(not(feature = "runtime-models"))]
    c9_state: f64,
    #[cfg(not(feature = "runtime-models"))]
    c9_alpha: f64,

    /// Test-only power-amp drive probe. Accumulates peak and mean-square of
    /// the signal actually presented to `PowerAmp::process`, i.e.
    /// `preamp_out * volume_pot_gain(vol)`. Used by the drive-headroom probe
    /// to compare against the amp's linearity envelope. `cfg(test)` so the
    /// hot loop carries nothing in release builds.
    #[cfg(test)]
    pub(crate) drive_peak: f64,
    #[cfg(test)]
    pub(crate) drive_sumsq: f64,
    #[cfg(test)]
    pub(crate) drive_n: u64,
    tremolo: Tremolo,
    #[cfg(not(feature = "runtime-models"))]
    oversampler: Oversampler,
    #[cfg(not(feature = "runtime-models"))]
    power_amp: PowerAmp,
    #[cfg(not(feature = "runtime-models"))]
    speaker: Speaker,

    // Pre-allocated scratch buffers
    voice_buf: Vec<f64>,
    sum_buf: Vec<f64>,
    #[cfg(not(feature = "runtime-models"))]
    up_buf: Vec<f64>,
    out_buf: Vec<f64>,
    #[cfg(feature = "runtime-models")]
    circuits: RuntimeCircuits,
    #[cfg(feature = "runtime-models")]
    warming_circuits: bool,

    // Sample rates
    sample_rate: f64,
    os_sample_rate: f64,
    /// Whether to oversample the preamp (false at >= 88.2 kHz host rates).
    oversample: bool,

    // MIDI state
    sustain_held: bool,
    mlp_enabled: bool,
    voice_character: VoiceCharacter,
    tremolo_response: f64,
    /// Per-voice calibration handed to each note-on. Only the hammer-contact and damper
    /// multipliers are host-settable; the rest stays at the shipping defaults.
    voicing: tables::CalibrationConfig,

    // Smoothed audio-rate params (target set by host, ramped per sample)
    volume: LinearSmoother,
    tremolo_depth: LinearSmoother,
    speaker_character: LinearSmoother,

    // Diagnostic counter — increments each time the NaN guard in
    // render_voices_to_preamp_out zeroes a block. A non-zero value at the
    // end of a render run means at least one voice produced non-finite
    // output and was force-freed without a release ramp.
    nan_guard_fires: u64,
}

/// Safety clamp for [`WurliEngine::set_hammer_contact_scale`]: keeps the dwell filter and onset ramp
/// inside the model's valid domain. Not a sourced range; the credible span is unmeasured.
pub const HAMMER_CONTACT_SCALE_RANGE: (f64, f64) = (0.5, 2.0);

/// Safety clamp for [`WurliEngine::set_damper_scale`]: wide enough to hear the trend, no wider. The
/// shipping damper rates are unsourced, so no range around them is sourced either.
pub const DAMPER_SCALE_RANGE: (f64, f64) = (0.25, 4.0);

impl WurliEngine {
    pub fn new(sample_rate: f64) -> Self {
        let oversample = sample_rate < 88_200.0;
        let os_sr = if oversample {
            sample_rate * 2.0
        } else {
            sample_rate
        };
        let ramp = ramp_samples_for_rate(sample_rate);
        Self {
            voices: (0..MAX_VOICES).map(|_| VoiceSlot::default()).collect(),
            age_counter: 0,
            #[cfg(not(feature = "runtime-models"))]
            preamp: DkPreamp::new(os_sr),
            reed_bar_trim: LinearSmoother::new(tables::R11_REED_BAR_VOLUME_DEFAULT, ramp),
            #[cfg(not(feature = "runtime-models"))]
            c9_state: 0.0,
            #[cfg(not(feature = "runtime-models"))]
            c9_alpha: 1.0,
            #[cfg(test)]
            drive_peak: 0.0,
            #[cfg(test)]
            drive_sumsq: 0.0,
            #[cfg(test)]
            drive_n: 0,
            tremolo: Tremolo::new(0.5, os_sr),
            #[cfg(not(feature = "runtime-models"))]
            oversampler: Oversampler::new(),
            // Power amp runs at the oversampled rate alongside the preamp so
            // the BE integrator inside the melange-generated solver gets a
            // small enough timestep to avoid manufacturing high-order harmonics
            // on harmonic-rich inputs. Speaker stays at base rate (linear,
            // doesn't benefit from oversampling).
            #[cfg(not(feature = "runtime-models"))]
            power_amp: PowerAmp::new_at_sample_rate(os_sr),
            #[cfg(not(feature = "runtime-models"))]
            speaker: Speaker::new(sample_rate),
            voice_buf: vec![0.0; MAX_BLOCK_SIZE],
            sum_buf: vec![0.0; MAX_BLOCK_SIZE],
            #[cfg(not(feature = "runtime-models"))]
            up_buf: vec![0.0; MAX_BLOCK_SIZE * 2],
            out_buf: vec![0.0; MAX_BLOCK_SIZE],
            #[cfg(feature = "runtime-models")]
            circuits: RuntimeCircuits::new(sample_rate, os_sr, CircuitMode::Fast),
            #[cfg(feature = "runtime-models")]
            warming_circuits: false,
            sample_rate,
            os_sample_rate: os_sr,
            oversample,
            sustain_held: false,
            mlp_enabled: false,
            voice_character: VoiceCharacter::default(),
            tremolo_response: 1.0,
            voicing: tables::CalibrationConfig::default(),
            volume: LinearSmoother::new(0.8, ramp),
            tremolo_depth: LinearSmoother::new(0.5, ramp),
            speaker_character: LinearSmoother::new(0.0, ramp),
            nan_guard_fires: 0,
        }
    }

    /// Construct with an initial mode without introducing a crossfade. Like
    /// `new`, call warm_up/reset/set_sample_rate during host initialization.
    #[cfg(feature = "runtime-models")]
    pub fn new_with_circuit_mode(sample_rate: f64, mode: CircuitMode) -> Self {
        let mut engine = Self::new(sample_rate);
        engine.circuits.mode = mode;
        engine.circuits.mix.snap_to(mode.weight());
        engine
    }

    /// Resume a stopped circuit with 100 ms of streamed live-input settling,
    /// then crossfade for 20 ms. The old mode remains audible while settling.
    /// No allocation, blocking warmup, solver reset or note-on occurs here.
    /// Cancelling settling keeps the old mode; an active fade reverses from its
    /// current blend without settling either already-running circuit again.
    #[cfg(feature = "runtime-models")]
    pub fn set_circuit_mode(&mut self, mode: CircuitMode) {
        if self.circuits.mode != mode {
            self.circuits.mode = mode;
            if self.circuits.preroll_remaining > 0 {
                // With two modes this returns to the still-audible endpoint.
                self.circuits.preroll_remaining = 0;
                self.circuits.mix.snap_to(mode.weight());
            } else if self.circuits.mix.samples_remaining > 0 {
                self.circuits.mix.set_target(mode.weight());
            } else {
                // Keep the existing endpoint and feed both histories in render.
                self.circuits.preroll_remaining = self.circuits.preroll_samples;
            }
        }
    }

    #[cfg(feature = "runtime-models")]
    pub fn circuit_mode(&self) -> CircuitMode {
        self.circuits.mode
    }

    pub fn reset(&mut self) {
        for slot in &mut self.voices {
            slot.state = VoiceState::Free;
            slot.voice = None;
            slot.steal_voice = None;
            slot.steal_fade = 0;
        }
        #[cfg(not(feature = "runtime-models"))]
        {
            self.preamp.reset();
            self.c9_state = 0.0;
            self.oversampler.reset();
            self.power_amp.reset();
            self.speaker.reset();
        }
        #[cfg(feature = "runtime-models")]
        self.circuits.reset();
        self.tremolo.reset();
        self.age_counter = 0;
        self.sustain_held = false;
        // Snap smoothers so a ramp doesn't survive a transport reset.
        self.volume.snap_to(self.volume.target);
        self.reed_bar_trim.snap_to(self.reed_bar_trim.target);
        self.tremolo_depth.snap_to(self.tremolo_depth.target);
        self.speaker_character
            .snap_to(self.speaker_character.target);
        self.warm_up();
    }

    /// Settle the preamp / tremolo oscillator / CdS-envelope to their steady
    /// operating point by running internal silence with the tremolo active. The
    /// real 200A preamp is always biased at its DC operating point; a chain
    /// started cold takes a while to reach the steady tremolo modulation (the
    /// retired shadow-pump used to lengthen this; the settle time was sized
    /// then), and a note struck during that window rides a
    /// deep gain excursion that reads as repeated attacks. Called after every
    /// `reset()` and `set_sample_rate()` so the first note is always clean.
    /// Not on the per-buffer path — a one-time settle, allocation-free.
    pub fn warm_up(&mut self) {
        #[cfg(feature = "runtime-models")]
        {
            self.warming_circuits = true;
        }
        let mut scratch = [0.0f32; 512];
        let total = (self.sample_rate * 0.6) as usize;
        let mut done = 0;
        while done < total {
            let len = 512.min(total - done);
            self.render(&mut scratch[..len]);
            done += len;
        }
        #[cfg(feature = "runtime-models")]
        {
            self.warming_circuits = false;
        }
    }

    pub fn set_sample_rate(&mut self, sr: f64) {
        self.sample_rate = sr;
        self.oversample = sr < 88_200.0;
        self.os_sample_rate = if self.oversample { sr * 2.0 } else { sr };
        #[cfg(not(feature = "runtime-models"))]
        {
            self.preamp = DkPreamp::new(self.os_sample_rate);
            self.c9_state = 0.0;
        }
        #[cfg(feature = "runtime-models")]
        {
            self.circuits = RuntimeCircuits::new(sr, self.os_sample_rate, self.circuits.mode);
            // The voice buffers can already exceed the constructor's default
            // capacity. Keep rebuilt circuit buffers aligned before warmup or
            // a host render reuses that previously reserved block size.
            self.circuits.ensure_buffer_capacity(self.sum_buf.len());
        }
        self.tremolo = Tremolo::new(self.tremolo_depth.target, self.os_sample_rate);
        self.tremolo.set_response_multiplier(self.tremolo_response);
        #[cfg(not(feature = "runtime-models"))]
        {
            self.oversampler = Oversampler::new();
            self.power_amp = PowerAmp::new_at_sample_rate(self.os_sample_rate);
            self.speaker = Speaker::new(sr);
        }
        let ramp = ramp_samples_for_rate(sr);
        self.volume.set_ramp_samples(ramp);
        self.reed_bar_trim.set_ramp_samples(ramp);
        self.tremolo_depth.set_ramp_samples(ramp);
        self.speaker_character.set_ramp_samples(ramp);
        self.warm_up();
    }

    pub fn ensure_buffer_capacity(&mut self, max_samples: usize) {
        if self.sum_buf.len() < max_samples {
            self.voice_buf.resize(max_samples, 0.0);
            self.sum_buf.resize(max_samples, 0.0);
            #[cfg(not(feature = "runtime-models"))]
            self.up_buf.resize(max_samples * 2, 0.0);
            #[cfg(feature = "runtime-models")]
            self.circuits.ensure_buffer_capacity(max_samples);
            self.out_buf.resize(max_samples, 0.0);
        }
    }

    // ── MIDI ────────────────────────────────────────────────────────────

    pub fn note_on(&mut self, note: u8, velocity: f32) {
        self.note_on_extended(note.clamp(tables::MIDI_LO, tables::MIDI_HI), velocity);
    }

    /// Play a full-range MIDI pitch without folding it onto an end reed.
    pub fn note_on_extended(&mut self, note: u8, velocity: f32) {
        if note > 127 {
            return;
        }

        // Re-strike of a sustained note: damp the old vibration before
        // the new attack (real 200A has one reed per pitch).
        for slot in &mut self.voices {
            if slot.state == VoiceState::Sustained && slot.midi_note == note {
                slot.state = VoiceState::Releasing;
                if let Some(ref mut voice) = slot.voice {
                    voice.note_off();
                }
            }
        }

        let slot_idx = self.allocate_voice();
        let slot = &mut self.voices[slot_idx];

        if slot.state != VoiceState::Free {
            // Stealing an active voice: 5 ms linear crossfade.
            let fade_samples = (self.sample_rate * 0.005) as u32;
            slot.steal_voice = slot.voice.take();
            slot.steal_fade = fade_samples;
            slot.steal_fade_len = fade_samples;
        }

        self.age_counter += 1;
        slot.voice = Some(Voice::note_on_with_config_and_character(
            note,
            velocity as f64,
            self.sample_rate,
            self.mlp_enabled,
            &self.voicing,
            self.voice_character,
        ));
        slot.state = VoiceState::Held;
        slot.midi_note = note;
        slot.age = self.age_counter;
    }

    pub fn note_off(&mut self, note: u8) {
        self.note_off_extended(note.clamp(tables::MIDI_LO, tables::MIDI_HI));
    }

    /// Release the exact MIDI pitch, including notes outside the physical keyboard.
    pub fn note_off_extended(&mut self, note: u8) {
        let oldest_idx = self
            .voices
            .iter()
            .enumerate()
            .filter(|(_, s)| s.state == VoiceState::Held && s.midi_note == note)
            .min_by_key(|(_, s)| s.age)
            .map(|(i, _)| i);
        if let Some(idx) = oldest_idx {
            if self.sustain_held {
                self.voices[idx].state = VoiceState::Sustained;
            } else {
                self.voices[idx].state = VoiceState::Releasing;
                if let Some(ref mut voice) = self.voices[idx].voice {
                    voice.note_off();
                }
            }
        }
    }

    /// Lift every key at once, as MIDI All Notes Off asks: each Held voice gets
    /// the note-off its key would give it, so with the pedal down it goes on
    /// sustaining until the pedal is released, and with the pedal up it damps.
    /// Pedal-Sustained voices are left to the pedal.
    ///
    /// `note_off` alone cannot do this: it releases only the oldest Held voice
    /// of a note, and a key can hold several (re-strikes without a note-off,
    /// and out-of-range notes clamped onto the keyboard's end keys).
    pub fn release_all_keys(&mut self) {
        let sustain = self.sustain_held;
        for slot in &mut self.voices {
            if slot.state == VoiceState::Held {
                if sustain {
                    slot.state = VoiceState::Sustained;
                } else {
                    slot.state = VoiceState::Releasing;
                    if let Some(ref mut voice) = slot.voice {
                        voice.note_off();
                    }
                }
            }
        }
    }

    /// Release every sounding note, pedal or not: all Held voices and all
    /// pedal-Sustained voices go through the normal damper release (no hard
    /// cut, unlike [`reset`](Self::reset)). The pedal state is left as it is,
    /// so a note played afterwards with the pedal still down sustains.
    ///
    /// This is stronger than MIDI All Notes Off, which leaves pedal-held notes
    /// sounding (see [`release_all_keys`](Self::release_all_keys)); use it for a
    /// host "release everything" request.
    pub fn all_notes_off(&mut self) {
        for slot in &mut self.voices {
            if matches!(slot.state, VoiceState::Held | VoiceState::Sustained) {
                slot.state = VoiceState::Releasing;
                if let Some(ref mut voice) = slot.voice {
                    voice.note_off();
                }
            }
        }
    }

    /// Stop every voice on `note` now (a CLAP note choke): each one fades out
    /// over 5 ms instead of ringing through its damper release, whatever its
    /// state. Out-of-range notes clamp onto the keyboard like note_on/note_off.
    pub fn choke(&mut self, note: u8) {
        self.choke_extended(note.clamp(tables::MIDI_LO, tables::MIDI_HI));
    }

    /// Choke the exact MIDI pitch without folding it onto an end reed.
    pub fn choke_extended(&mut self, note: u8) {
        let fade = self.quick_fade_samples();
        for slot in &mut self.voices {
            if slot.state != VoiceState::Free && slot.midi_note == note {
                Self::fade_out_slot(slot, fade);
            }
        }
    }

    /// Silence every voice now (MIDI All Sound Off, a wildcard CLAP choke):
    /// held, sustained and releasing voices all fade out over 5 ms, so there
    /// is no click and no release tail. Unlike [`reset`](Self::reset) the
    /// signal chain keeps its state (no tremolo re-settle), and the pedal
    /// state is left as it is.
    pub fn all_sound_off(&mut self) {
        let fade = self.quick_fade_samples();
        for slot in &mut self.voices {
            if slot.state != VoiceState::Free {
                Self::fade_out_slot(slot, fade);
            }
        }
    }

    /// Length of the stop fade: 5 ms, the same as the voice-steal crossfade.
    fn quick_fade_samples(&self) -> u32 {
        ((self.sample_rate * 0.005) as u32).max(1)
    }

    /// Hand a slot's voice to the steal fade and free the slot. The render
    /// loop keeps fading `steal_voice` after the slot is free; a fade already
    /// in progress on this slot is replaced (it is part-way to silence).
    fn fade_out_slot(slot: &mut VoiceSlot, fade: u32) {
        if let Some(voice) = slot.voice.take() {
            slot.steal_voice = Some(voice);
            slot.steal_fade = fade;
            slot.steal_fade_len = fade;
        }
        slot.state = VoiceState::Free;
    }

    pub fn set_sustain(&mut self, held: bool) {
        if self.sustain_held && !held {
            // Pedal release: damp every voice that was held by the pedal.
            for slot in &mut self.voices {
                if slot.state == VoiceState::Sustained {
                    slot.state = VoiceState::Releasing;
                    if let Some(ref mut voice) = slot.voice {
                        voice.note_off();
                    }
                }
            }
        }
        self.sustain_held = held;
    }

    // ── Param setters ────────────────────────────────────────────────────

    /// One-pole lowpass coefficient for corner `fc` at rate `sr`
    /// (exact-decay form; a corner above Nyquist degrades to passthrough).
    fn one_pole_alpha(fc: f64, sr: f64) -> f64 {
        if !fc.is_finite() || fc >= 0.5 * sr {
            1.0
        } else {
            1.0 - (-2.0 * std::f64::consts::PI * fc / sr).exp()
        }
    }

    pub fn set_volume(&mut self, v: f64) {
        self.volume.set_target(v);
    }

    /// R-11 "Reed Bar Trim", ohms (0..=25 000): the per-unit factory trimmer
    /// between the preamp output and the volume pot. Undocumented setting;
    /// the default (tables::R11_REED_BAR_VOLUME_DEFAULT, 17.2K) is transferred
    /// from the non-A factory calibration, an inference pending a bench reading.
    pub fn set_reed_bar_trim(&mut self, r11_ohms: f64) {
        self.reed_bar_trim
            .set_target(r11_ohms.clamp(0.0, tables::R11_REED_BAR_VOLUME_MAX));
    }

    pub fn set_tremolo_depth(&mut self, depth: f64) {
        self.tremolo_depth.set_target(depth);
    }

    pub fn set_speaker_character(&mut self, c: f64) {
        self.speaker_character.set_target(c);
    }

    /// Hammer contact-time multiplier (experimental; 1.0 = shipping, clamped to
    /// [`HAMMER_CONTACT_SCALE_RANGE`]).
    /// Below 1.0 models a harder hammer pad: shorter contact, so the upper modes are excited
    /// more strongly and the onset ramp is shorter. Above 1.0 models a softer pad. Latched at
    /// note-on; the range is not sourced (see `hammer::dwell_time`).
    pub fn set_hammer_contact_scale(&mut self, scale: f64) {
        let (lo, hi) = HAMMER_CONTACT_SCALE_RANGE;
        self.voicing.hammer_contact_scale = scale.clamp(lo, hi);
    }

    /// Damper-rate multiplier (experimental; 1.0 = shipping, clamped to [`DAMPER_SCALE_RANGE`]). Below 1.0
    /// is a weaker damper (the release rings longer), above it a firmer one. Every voice uses
    /// the value current at its note-off; a voice already damping keeps its rate. The shipping
    /// rates are themselves unsourced, so is any range around them.
    pub fn set_damper_scale(&mut self, scale: f64) {
        let (lo, hi) = DAMPER_SCALE_RANGE;
        let scale = scale.clamp(lo, hi);
        self.voicing.damper_scale = scale;
        for voice in self
            .voices
            .iter_mut()
            .filter_map(|slot| slot.voice.as_mut())
        {
            voice.set_damper_scale(scale);
        }
    }

    pub fn set_mlp_enabled(&mut self, on: bool) {
        self.mlp_enabled = on;
    }

    /// Note-on controls affect new notes only. Existing voices keep their
    /// excitation and decay parameters until released.
    /// Decay time ranges from 0.5x to 20x; other character controls retain 0.5x–2x.
    pub fn set_reed_decay(&mut self, multiplier: f64) {
        self.voice_character.reed_decay = if multiplier.is_finite() {
            multiplier.clamp(0.5, 20.0)
        } else {
            1.0
        };
    }

    pub fn set_hammer_hardness(&mut self, multiplier: f64) {
        self.voice_character.hammer_hardness = bounded_multiplier(multiplier);
    }

    pub fn set_pickup_drive(&mut self, multiplier: f64) {
        self.voice_character.pickup_drive = bounded_multiplier(multiplier);
    }

    /// Scales the CdS cell's attack and release response time. The Twin-T
    /// oscillator frequency and waveform remain circuit-derived.
    pub fn set_tremolo_response(&mut self, multiplier: f64) {
        self.tremolo_response = bounded_multiplier(multiplier);
        self.tremolo.set_response_multiplier(self.tremolo_response);
    }

    pub fn set_noise_enabled(&mut self, on: bool) {
        #[cfg(not(feature = "runtime-models"))]
        self.preamp.set_noise_enabled(on);
        #[cfg(feature = "runtime-models")]
        {
            self.circuits.fast.preamp.set_noise_enabled(on);
            self.circuits.heavy.preamp.set_noise_enabled(on);
        }
    }

    pub fn set_noise_gain(&mut self, gain: f64) {
        #[cfg(not(feature = "runtime-models"))]
        self.preamp.set_thermal_gain(gain);
        #[cfg(feature = "runtime-models")]
        {
            self.circuits.fast.preamp.set_thermal_gain(gain);
            self.circuits.heavy.preamp.set_thermal_gain(gain);
        }
    }

    /// Enable / disable rail sag modeling on the power amp. Only the opt-in
    /// melange amp models it (on by default there; +0.66 % CPU); on the shipping
    /// behavioral amp this is a no-op. Toggle off for bit-compat A/B against
    /// the pre-rail-sag adapter. See `power_amp.rs` `RailDynamics` and
    /// `docs/research/output-stage.md` §4.3.1.
    pub fn set_rail_sag(&mut self, on: bool) {
        #[cfg(not(feature = "runtime-models"))]
        self.power_amp.set_rail_sag(on);
        #[cfg(feature = "runtime-models")]
        {
            self.circuits.fast.amp.set_rail_sag(on);
            self.circuits.heavy.amp.set_rail_sag(on);
        }
    }

    pub fn rail_sag_enabled(&self) -> bool {
        #[cfg(not(feature = "runtime-models"))]
        {
            self.power_amp.rail_sag_enabled()
        }
        #[cfg(feature = "runtime-models")]
        {
            match self.circuits.mode {
                CircuitMode::Fast => self.circuits.fast.amp.rail_sag_enabled(),
                CircuitMode::Heavy => self.circuits.heavy.amp.rail_sag_enabled(),
            }
        }
    }

    /// Power-amp diagnostic snapshot:
    /// `(clamp_count, nr_max_iter_count, peak_output_volts)`.
    /// Use during diagnostic renders to see if the divergence guard is
    /// firing, NR is failing, or the amp is producing unphysical voltages.
    pub fn power_amp_diag(&self) -> (u64, u64, f64) {
        #[cfg(not(feature = "runtime-models"))]
        {
            self.power_amp.diag_snapshot()
        }
        #[cfg(feature = "runtime-models")]
        {
            match self.circuits.mode {
                CircuitMode::Fast => self.circuits.fast.amp.diag_snapshot(),
                CircuitMode::Heavy => self.circuits.heavy.amp.diag_snapshot(),
            }
        }
    }

    // ── Render ───────────────────────────────────────────────────────────

    /// Render `out.len()` mono samples through the full chain.
    #[cfg(not(feature = "runtime-models"))]
    pub fn render(&mut self, out: &mut [f32]) {
        let len = out.len();
        if len == 0 {
            return;
        }
        self.ensure_buffer_capacity(len);

        // After this call, out_buf holds the post-power-amp signal at base rate
        // (preamp + volume network + power amp ran inside the OS bus together).
        self.render_voices_to_preamp_out(0, len);

        for (i, sample_slot) in out.iter_mut().enumerate() {
            let speaker_char = self.speaker_character.next();
            self.speaker.set_character(speaker_char);
            let shaped = self.speaker.process(self.out_buf[i]);
            // User volume is the drawn pot between preamp and power amp and
            // was applied in render_voices_to_preamp_out. POST_SPEAKER_GAIN is
            // the rail-to-full-scale mapping (0 dB: ±22 V = ±1.0). No
            // nonlinear ceiling — output peak management belongs in the host
            // host, per the project's scope rules.
            let post_gain = shaped * tables::POST_SPEAKER_GAIN;
            let sample = post_gain as f32;
            // NaN guard: non-finite samples crash PipeWire/JACK audio engines.
            *sample_slot = if sample.is_finite() {
                sample
            } else {
                self.preamp.reset();
                self.c9_state = 0.0;
                self.oversampler.reset();
                self.power_amp.reset();
                self.speaker.reset();
                0.0f32
            };
        }

        self.cleanup_voices();
    }

    /// Render one circuit pair, or both during 100 ms of live-input settling
    /// followed by a 20 ms crossfade. No extra voice bank or blocking warmup.
    /// Buffers are allocated at construction/ensure_buffer_capacity, never here.
    #[cfg(feature = "runtime-models")]
    pub fn render(&mut self, out: &mut [f32]) {
        let mut position = 0;
        while position < out.len() {
            // Start the fade exactly after the last settling sample and stop
            // the outgoing circuit exactly at fade completion, even mid-block.
            let transition_limit = if self.circuits.preroll_remaining > 0 {
                self.circuits.preroll_remaining as usize
            } else if self.circuits.mix.samples_remaining > 0 {
                self.circuits.mix.samples_remaining as usize
            } else {
                usize::MAX
            };
            let len = (out.len() - position)
                .min(self.sum_buf.len())
                .min(transition_limit);
            let (fast, heavy) = self.circuits.running(self.warming_circuits);
            self.render_voices_to_preamp_out(0, len);
            for (i, sample_slot) in out[position..position + len].iter_mut().enumerate() {
                let character = self.speaker_character.next();
                let a = if fast {
                    self.circuits.fast.shape(i, character)
                } else {
                    0.0
                };
                let b = if heavy {
                    self.circuits.heavy.shape(i, character)
                } else {
                    0.0
                };
                let mix = self.circuits.mix.next();
                // Endpoint branches retain the original floating-point output.
                let shaped = if mix == 0.0 {
                    a
                } else if mix == 1.0 {
                    b
                } else {
                    a + (b - a) * mix
                };
                let sample = (shaped * tables::POST_SPEAKER_GAIN) as f32;
                *sample_slot = if sample.is_finite() {
                    sample
                } else {
                    // Existing fault recovery, never entered merely by a switch.
                    if fast {
                        self.circuits.fast.reset();
                    }
                    if heavy {
                        self.circuits.heavy.reset();
                    }
                    0.0
                };
            }
            if self.circuits.preroll_remaining > 0 {
                self.circuits.preroll_remaining -= len as u32;
                if self.circuits.preroll_remaining == 0 {
                    self.circuits.mix.set_target(self.circuits.mode.weight());
                }
            }
            self.cleanup_voices();
            position += len;
        }
    }

    #[cfg(feature = "runtime-models")]
    fn render_runtime_circuit_bus(&mut self, offset: usize, len: usize) {
        let factor = if self.oversample { 2 } else { 1 };
        for i in 0..len {
            self.tremolo.set_depth(self.tremolo_depth.next());
            let vol = self.volume.next();
            let r11 = self.reed_bar_trim.next();
            self.circuits.gain[i] = tables::volume_pot_gain(vol, r11);
            self.circuits.alpha[i] =
                Self::one_pole_alpha(tables::volume_pot_pole_hz(vol, r11), self.os_sample_rate);
            for j in 0..factor {
                self.circuits.ldr[i * factor + j] = self.tremolo.process();
            }
        }
        let (fast, heavy) = self.circuits.running(self.warming_circuits);
        if fast {
            self.circuits.fast.process_bus(
                &self.sum_buf[..len],
                &self.circuits.ldr[..len * factor],
                &self.circuits.gain[..len],
                &self.circuits.alpha[..len],
                self.oversample,
            );
        }
        if heavy {
            self.circuits.heavy.process_bus(
                &self.sum_buf[..len],
                &self.circuits.ldr[..len * factor],
                &self.circuits.gain[..len],
                &self.circuits.alpha[..len],
                self.oversample,
            );
        }
        // Preserve the existing introspection endpoint (pre speaker/gain).
        let selected = match self.circuits.mode {
            CircuitMode::Fast => &self.circuits.fast.out,
            CircuitMode::Heavy => &self.circuits.heavy.out,
        };
        self.out_buf[offset..offset + len].copy_from_slice(&selected[..len]);
        #[cfg(test)]
        {
            let (peak, sumsq, n) = match self.circuits.mode {
                CircuitMode::Fast => (
                    self.circuits.fast.drive_peak,
                    self.circuits.fast.drive_sumsq,
                    self.circuits.fast.drive_n,
                ),
                CircuitMode::Heavy => (
                    self.circuits.heavy.drive_peak,
                    self.circuits.heavy.drive_sumsq,
                    self.circuits.heavy.drive_n,
                ),
            };
            self.drive_peak = peak;
            self.drive_sumsq = sumsq;
            self.drive_n = n;
        }
    }

    /// Render voices through the preamp and write into `self.out_buf[offset..offset+len]`.
    /// Pulled out so introspection tests can call it without going through the chain.
    pub(crate) fn render_voices_to_preamp_out(&mut self, offset: usize, len: usize) {
        // Sum all active voices
        self.sum_buf[..len].fill(0.0);
        for slot in &mut self.voices {
            if slot.state == VoiceState::Free && slot.steal_voice.is_none() {
                continue;
            }

            if let Some(ref mut voice) = slot.voice {
                voice.render(&mut self.voice_buf[..len]);
                for (sum, sample) in self.sum_buf[..len]
                    .iter_mut()
                    .zip(self.voice_buf[..len].iter())
                {
                    *sum += *sample;
                }
            }

            if let Some(ref mut steal) = slot.steal_voice {
                steal.render(&mut self.voice_buf[..len]);
                let fade_len = slot.steal_fade_len as f64;
                for (i, (sum, sample)) in self.sum_buf[..len]
                    .iter_mut()
                    .zip(self.voice_buf[..len].iter())
                    .enumerate()
                {
                    let remaining = slot.steal_fade.saturating_sub(i as u32);
                    *sum += *sample * (remaining as f64 / fade_len);
                }
                slot.steal_fade = slot.steal_fade.saturating_sub(len as u32);
                if slot.steal_fade == 0 {
                    slot.steal_voice = None;
                }
            }
        }

        // NaN guard: catch non-finite voice output BEFORE the oversampler.
        // Once NaN enters IIR allpass filter state, it persists and causes
        // per-sample preamp resets (expensive full_dc_solve) → xruns → frozen audio.
        if self.sum_buf[..len].iter().any(|s| !s.is_finite()) {
            self.nan_guard_fires += 1;
            self.sum_buf[..len].fill(0.0);
            for slot in &mut self.voices {
                if slot.state == VoiceState::Free && slot.steal_voice.is_none() {
                    continue;
                }
                if let Some(ref mut voice) = slot.voice {
                    voice.render(&mut self.voice_buf[..len]);
                    if self.voice_buf[..len].iter().any(|s| !s.is_finite()) {
                        slot.state = VoiceState::Free;
                        slot.voice = None;
                    }
                }
                if let Some(ref mut steal) = slot.steal_voice {
                    steal.render(&mut self.voice_buf[..len]);
                    if self.voice_buf[..len].iter().any(|s| !s.is_finite()) {
                        slot.steal_voice = None;
                        slot.steal_fade = 0;
                    }
                }
            }
        }

        #[cfg(feature = "runtime-models")]
        self.render_runtime_circuit_bus(offset, len);
        #[cfg(not(feature = "runtime-models"))]
        {
            if self.oversample {
                self.oversampler
                    .upsample_2x(&self.sum_buf[..len], &mut self.up_buf[..len * 2]);

                // Per base-rate sample: advance tremolo depth + volume smoothers
                // once. Run the preamp + power amp twice (once per OS sample) so
                // both nonlinear stages see 88.2 kHz timestep — critical for the
                // melange BE integrator inside the power amp not to manufacture
                // high-order harmonics from the harmonic-rich pickup output.
                for i in 0..len {
                    let depth = self.tremolo_depth.next();
                    self.tremolo.set_depth(depth);
                    // The drawn volume network: preamp open-circuit output → R-11
                    // → 10K pot at the user's position → amp input (loaded), with
                    // C-9 against the wiper's source resistance as a one-pole.
                    let vol = self.volume.next();
                    let r11 = self.reed_bar_trim.next();
                    let drive_gain = self.preamp.open_circuit_output_factor()
                        * tables::volume_pot_gain(vol, r11);
                    self.c9_alpha = Self::one_pole_alpha(
                        tables::volume_pot_pole_hz(vol, r11),
                        self.os_sample_rate,
                    );

                    for j in 0..2 {
                        let idx = i * 2 + j;
                        let r_ldr = self.tremolo.process();
                        self.preamp.set_ldr_resistance(r_ldr);
                        let preamp_out = self.preamp.process_sample(self.up_buf[idx]);
                        self.c9_state += self.c9_alpha * (preamp_out * drive_gain - self.c9_state);
                        let drive = self.c9_state;
                        #[cfg(test)]
                        {
                            self.drive_peak = self.drive_peak.max(drive.abs());
                            self.drive_sumsq += drive * drive;
                            self.drive_n += 1;
                        }
                        self.up_buf[idx] = self.power_amp.process(drive);
                    }
                }

                self.oversampler.downsample_2x(
                    &self.up_buf[..len * 2],
                    &mut self.out_buf[offset..offset + len],
                );
            } else {
                for i in 0..len {
                    let depth = self.tremolo_depth.next();
                    self.tremolo.set_depth(depth);
                    let r_ldr = self.tremolo.process();
                    self.preamp.set_ldr_resistance(r_ldr);
                    let preamp_out = self.preamp.process_sample(self.sum_buf[i]);
                    let vol = self.volume.next();
                    let r11 = self.reed_bar_trim.next();
                    let drive_gain = self.preamp.open_circuit_output_factor()
                        * tables::volume_pot_gain(vol, r11);
                    self.c9_alpha = Self::one_pole_alpha(
                        tables::volume_pot_pole_hz(vol, r11),
                        self.os_sample_rate,
                    );
                    self.c9_state += self.c9_alpha * (preamp_out * drive_gain - self.c9_state);
                    let drive = self.c9_state;
                    #[cfg(test)]
                    {
                        self.drive_peak = self.drive_peak.max(drive.abs());
                        self.drive_sumsq += drive * drive;
                        self.drive_n += 1;
                    }
                    self.out_buf[offset + i] = self.power_amp.process(drive);
                }
            }
        }
    }

    fn allocate_voice(&self) -> usize {
        let mut best_idx = 0;
        let mut best_priority = u64::MAX;

        for (i, slot) in self.voices.iter().enumerate() {
            // Free (immediate) > oldest Releasing > oldest Sustained > oldest Held.
            // Sustained voices already had their key released — less disruptive
            // to steal than a Held voice the player is still pressing.
            let priority = match slot.state {
                VoiceState::Free => return i,
                VoiceState::Releasing => slot.age,
                VoiceState::Sustained => slot.age + u64::MAX / 4,
                VoiceState::Held => slot.age + u64::MAX / 2,
            };
            if priority < best_priority {
                best_priority = priority;
                best_idx = i;
            }
        }

        best_idx
    }

    fn cleanup_voices(&mut self) {
        for slot in &mut self.voices {
            if slot.state != VoiceState::Free
                && let Some(ref voice) = slot.voice
                && voice.is_silent()
            {
                slot.state = VoiceState::Free;
                slot.voice = None;
            }
        }
    }

    // ── Test/inspection helpers ──────────────────────────────────────────

    #[doc(hidden)]
    pub fn active_voice_count(&self) -> usize {
        self.voices
            .iter()
            .filter(|s| s.state != VoiceState::Free)
            .count()
    }

    #[doc(hidden)]
    pub fn held_voice_count(&self) -> usize {
        self.voices
            .iter()
            .filter(|s| s.state == VoiceState::Held)
            .count()
    }

    #[doc(hidden)]
    pub fn sustained_voice_count(&self) -> usize {
        self.voices
            .iter()
            .filter(|s| s.state == VoiceState::Sustained)
            .count()
    }

    #[doc(hidden)]
    pub fn has_steal_voice_for(&self, note: u8) -> bool {
        self.voices
            .iter()
            .any(|s| s.midi_note == note && s.steal_voice.is_some())
    }

    #[doc(hidden)]
    pub fn count_voices_in_state(&self, state: VoiceState) -> usize {
        self.voices.iter().filter(|s| s.state == state).count()
    }

    #[doc(hidden)]
    pub fn count_voices_with_note_in_state(&self, note: u8, state: VoiceState) -> usize {
        self.voices
            .iter()
            .filter(|s| s.state == state && s.midi_note == note)
            .count()
    }

    /// Forces sustain state directly — bypasses the pedal release damping
    /// path. Test-only; production code should use `set_sustain`.
    #[doc(hidden)]
    pub fn force_sustain_held(&mut self, held: bool) {
        self.sustain_held = held;
    }

    #[doc(hidden)]
    /// Number of times the NaN guard has zeroed a block since construction
    /// or the last `reset_nan_guard_count()`. Use for diagnostics — a
    /// non-zero value means at least one voice produced non-finite output
    /// and was force-freed without a release ramp.
    pub fn nan_guard_fires(&self) -> u64 {
        self.nan_guard_fires
    }

    /// Reset the NaN-guard fire counter to zero. Useful when scoping a
    /// counter to a specific MIDI passage rather than the engine lifetime.
    pub fn reset_nan_guard_count(&mut self) {
        self.nan_guard_fires = 0;
    }

    pub fn is_sustain_held(&self) -> bool {
        self.sustain_held
    }
}

fn bounded_multiplier(value: f64) -> f64 {
    if value.is_finite() {
        value.clamp(0.5, 2.0)
    } else {
        1.0
    }
}

fn ramp_samples_for_rate(sample_rate: f64) -> u32 {
    // 5 ms equivalent at any rate.
    ((sample_rate * 0.005) as u32).max(1)
}

#[cfg(test)]
mod tests {
    use super::*;

    #[cfg(feature = "runtime-models")]
    #[test]
    fn runtime_model_capacity_survives_sample_rate_change() {
        let capacity = MAX_BLOCK_SIZE + 257;
        let mut engine = WurliEngine::new_with_circuit_mode(48_000.0, CircuitMode::Fast);
        engine.ensure_buffer_capacity(capacity);
        engine.set_sample_rate(44_100.0);
        // Hosts may reserve the same block size again after initialization.
        engine.ensure_buffer_capacity(capacity);
        let mut output = vec![0.0; capacity];
        engine.render(&mut output);
        assert!(output.iter().all(|x| x.is_finite()));
        engine.set_circuit_mode(CircuitMode::Heavy);
        engine.render(&mut output);
        assert!(output.iter().all(|x| x.is_finite()));
        assert_eq!(engine.circuit_mode(), CircuitMode::Heavy);
    }

    #[cfg(feature = "runtime-models")]
    #[test]
    fn runtime_model_preroll_keeps_old_audio_and_has_exact_boundaries() {
        let mut engine = WurliEngine::new_with_circuit_mode(48_000.0, CircuitMode::Fast);
        let mut reference = WurliEngine::new_with_circuit_mode(48_000.0, CircuitMode::Fast);
        assert_eq!(engine.circuits.preroll_remaining, 0);
        assert_eq!(engine.circuits.mix.samples_remaining, 0);
        assert_eq!(engine.circuits.mix.current, 0.0);
        engine.note_on(60, 0.8);
        reference.note_on(60, 0.8);
        let age = engine.age_counter;
        let compare_old_audio = |engine: &mut WurliEngine, reference: &mut WurliEngine, len| {
            let mut actual = vec![0.0; len];
            let mut expected = vec![0.0; len];
            engine.render(&mut actual);
            reference.render(&mut expected);
            assert_eq!(
                actual.iter().map(|x| x.to_bits()).collect::<Vec<_>>(),
                expected.iter().map(|x| x.to_bits()).collect::<Vec<_>>(),
                "settling must leave outgoing audio unchanged"
            );
        };
        compare_old_audio(&mut engine, &mut reference, 128);
        let heavy_before = engine.circuits.heavy.drive_n;
        engine.set_circuit_mode(CircuitMode::Heavy);
        assert_eq!(engine.circuits.preroll_remaining, 4800);
        compare_old_audio(&mut engine, &mut reference, 17);
        assert_eq!(engine.circuits.heavy.drive_n - heavy_before, 34);
        assert_eq!(engine.circuits.preroll_remaining, 4783);
        assert_eq!(engine.circuits.mix.current, 0.0);
        engine.set_circuit_mode(CircuitMode::Heavy);
        assert_eq!(
            engine.circuits.preroll_remaining, 4783,
            "same target must not restart settling"
        );
        engine.set_circuit_mode(CircuitMode::Fast);
        assert_eq!(engine.circuits.preroll_remaining, 0);
        assert_eq!(engine.circuits.mix.samples_remaining, 0);
        let heavy_before = engine.circuits.heavy.drive_n;
        compare_old_audio(&mut engine, &mut reference, 48);
        assert_eq!(
            engine.circuits.heavy.drive_n, heavy_before,
            "cancelled incoming chain must stop"
        );

        engine.set_circuit_mode(CircuitMode::Heavy);
        compare_old_audio(&mut engine, &mut reference, 4799);
        assert_eq!(engine.circuits.preroll_remaining, 1);
        let heavy_before = engine.circuits.heavy.drive_n;
        let mut edge = [0.0; 2];
        let mut old = [0.0; 2];
        engine.render(&mut edge);
        reference.render(&mut old);
        assert_eq!(
            edge[0].to_bits(),
            old[0].to_bits(),
            "last settling sample stays at old endpoint"
        );
        assert_eq!(engine.circuits.heavy.drive_n - heavy_before, 4);
        assert_eq!(engine.circuits.preroll_remaining, 0);
        assert_eq!(engine.circuits.mix.samples_remaining, 959);
        assert!(engine.circuits.mix.current > 0.0);
        let blend = engine.circuits.mix.current;
        engine.set_circuit_mode(CircuitMode::Fast);
        assert_eq!(
            engine.circuits.mix.current, blend,
            "fade reversal must be continuous"
        );
        assert_eq!(
            engine.circuits.preroll_remaining, 0,
            "both chains are already running"
        );
        let heavy_before = engine.circuits.heavy.drive_n;
        engine.render(&mut [0.0; 961]);
        assert_eq!(
            engine.circuits.heavy.drive_n - heavy_before,
            1920,
            "hidden chain stops at the fade endpoint inside the block"
        );
        assert_eq!(engine.circuits.mix.current, 0.0);
        assert_eq!(engine.age_counter, age);
        assert_eq!(engine.held_voice_count(), 1);

        engine.set_circuit_mode(CircuitMode::Heavy);
        engine.reset();
        assert_eq!(engine.circuits.preroll_remaining, 0);
        assert_eq!(engine.circuits.mix.current, 1.0);
        engine.set_circuit_mode(CircuitMode::Fast);
        engine.set_sample_rate(96_000.0);
        assert_eq!(engine.circuits.preroll_remaining, 0);
        assert_eq!(engine.circuits.preroll_samples, 9600);
        assert_eq!(engine.circuits.mix.current, 0.0);
    }

    #[cfg(feature = "runtime-models")]
    #[test]
    fn runtime_model_switch_preserves_notes_and_stops_hidden_chain() {
        let mut engine = WurliEngine::new_with_circuit_mode(48_000.0, CircuitMode::Fast);
        engine.warm_up();
        engine.note_on(60, 0.8);
        engine.note_on(67, 0.6);
        let age = engine.age_counter;
        let heavy_before = engine.circuits.heavy.drive_n;
        engine.render(&mut [0.0; 128]);
        assert_eq!(engine.circuits.heavy.drive_n, heavy_before);
        engine.set_circuit_mode(CircuitMode::Heavy);
        let mut settling = vec![0.0; engine.circuits.preroll_samples as usize];
        engine.render(&mut settling);
        assert!(settling.iter().all(|x| x.is_finite()));
        assert_eq!(engine.circuits.preroll_remaining, 0);
        assert_eq!(engine.circuits.mix.current, 0.0);
        let fast_before = engine.circuits.fast.drive_n;
        let heavy_before = engine.circuits.heavy.drive_n;
        let mut transition = [0.0; 96];
        engine.render(&mut transition);
        assert!(transition.iter().all(|x| x.is_finite()));
        assert_eq!(engine.circuits.fast.drive_n - fast_before, 192);
        assert_eq!(engine.circuits.heavy.drive_n - heavy_before, 192);
        let mix = engine.circuits.mix.current;
        assert!(mix > 0.0 && mix < 1.0);
        engine.set_circuit_mode(CircuitMode::Fast);
        assert_eq!(
            engine.circuits.mix.current, mix,
            "reversal must not jump the blend"
        );
        engine.render(&mut [0.0; 17]);
        assert!(engine.circuits.mix.current < mix);
        engine.set_circuit_mode(CircuitMode::Heavy);
        let mut transition = [0.0; 1200];
        engine.render(&mut transition);
        assert!(transition.iter().all(|x| x.is_finite()));
        assert_eq!(engine.circuits.mix.current, 1.0);
        let fast_before = engine.circuits.fast.drive_n;
        engine.render(&mut [0.0; 257]);
        assert_eq!(engine.circuits.fast.drive_n, fast_before);
        assert_eq!(
            engine.age_counter, age,
            "switching must not create/reseed voices"
        );
        assert_eq!(engine.held_voice_count(), 2);
        assert_eq!(engine.active_voice_count(), 2);
    }

    fn engine() -> WurliEngine {
        WurliEngine::new(44_100.0)
    }

    #[test]
    fn test_engine_instantiates() {
        let e = engine();
        assert_eq!(e.voices.len(), MAX_VOICES);
        assert_eq!(e.sample_rate, 44_100.0);
    }

    #[test]
    fn test_note_on_allocates_voice() {
        let mut e = engine();
        e.note_on(60, 0.8);
        assert_eq!(e.held_voice_count(), 1);
    }

    #[test]
    fn test_note_off_releases_voice() {
        let mut e = engine();
        e.note_on(60, 0.8);
        e.note_off(60);
        assert_eq!(e.held_voice_count(), 0);
    }

    #[test]
    fn test_polyphony_up_to_max_voices() {
        let mut e = engine();
        for n in 0..MAX_VOICES {
            e.note_on((36 + n) as u8, 0.8);
        }
        assert_eq!(e.held_voice_count(), MAX_VOICES);
    }

    #[test]
    fn test_voice_stealing_when_full() {
        let mut e = engine();
        for n in 0..MAX_VOICES {
            e.note_on((36 + n) as u8, 0.8);
        }
        e.note_on(96, 0.8);
        assert_eq!(e.held_voice_count(), MAX_VOICES);
        assert!(e.has_steal_voice_for(96));
    }

    #[test]
    fn test_render_produces_output() {
        let mut e = engine();
        e.note_on(60, 0.8);
        let mut buf = vec![0.0f32; 256];
        e.render(&mut buf);
        let energy: f64 = buf.iter().map(|s| (*s as f64) * (*s as f64)).sum();
        assert!(energy > 0.0, "render produced silence after note-on");
    }

    #[test]
    fn test_render_no_notes_is_near_silent() {
        // Idle output has a small chain-startup DC settling transient
        // (preamp/speaker biasing). Threshold mirrors the legacy plugin
        // test (0.03) which carried the same accommodation.
        let mut e = engine();
        let mut buf = vec![0.0f32; 512];
        e.render(&mut buf);
        let peak = buf.iter().map(|s| s.abs()).fold(0.0f32, f32::max);
        assert!(peak < 0.05, "idle output peak {peak} too high");
    }

    #[test]
    fn test_reset_clears_voices() {
        let mut e = engine();
        e.note_on(60, 0.8);
        e.note_on(72, 0.8);
        e.reset();
        assert_eq!(e.active_voice_count(), 0);
    }

    #[test]
    fn test_sustain_defers_note_off() {
        let mut e = engine();
        e.set_sustain(true);
        e.note_on(60, 0.8);
        e.note_off(60);
        assert_eq!(e.sustained_voice_count(), 1);
        assert_eq!(e.held_voice_count(), 0);
        e.set_sustain(false);
        // Releasing now (note_off triggered on pedal release)
        assert_eq!(e.sustained_voice_count(), 0);
    }

    #[test]
    fn test_volume_smoother_ramps() {
        let mut e = engine();
        e.set_volume(1.0);
        let mut buf = vec![0.0f32; 1];
        e.render(&mut buf); // advances smoother by 1 sample
        // Default starts at 0.5, ramping toward 1.0 over ~220 samples
        assert!(e.volume.current > 0.5);
        assert!(e.volume.current < 1.0);
    }

    /// Structural invariant (2026-09-23): with the mapping FULL_SCALE_VOLTS = the
    /// amp's rail, the output cannot exceed full scale at ANY setting — the rail
    /// tanh bounds the amp and nothing downstream has gain > 1. Sweep the
    /// settings that raise the drive or add downstream stages: trim at its
    /// hottest (0 Ω) and at default, full volume, tremolo off and full, speaker
    /// bypass and authentic, MLP corrections off and on; worst-phase ff chord.
    fn worst_peak_across_settings(sr: f64) -> (f32, String) {
        let mut worst = (0.0f32, String::new());
        for &trim in &[0.0f64, tables::R11_REED_BAR_VOLUME_DEFAULT] {
            for &trem in &[0.0f64, 1.0] {
                for &spk in &[0.0f64, 1.0] {
                    for &mlp in &[false, true] {
                        let mut e = WurliEngine::new(sr);
                        e.ensure_buffer_capacity(1024);
                        e.set_volume(1.0);
                        e.set_reed_bar_trim(trim);
                        e.set_tremolo_depth(trem);
                        e.set_speaker_character(spk);
                        e.set_mlp_enabled(mlp);
                        e.set_noise_enabled(false);
                        e.warm_up();
                        let mut buf = vec![0.0f32; 1024];
                        for _ in 0..6 {
                            e.render(&mut buf);
                        }
                        // Worst-phase onset from the peak-invariant probe (≈162 ms).
                        let delay = (sr * 0.162) as usize;
                        let mut pos = 0;
                        while pos < delay {
                            let len = 1024.min(delay - pos);
                            e.render(&mut buf[..len]);
                            pos += len;
                        }
                        for &n in &[48u8, 55, 60, 63, 67, 70] {
                            e.note_on(n, 1.0);
                        }
                        let mut peak = 0.0f32;
                        let mut pos2 = 0;
                        while pos2 < sr as usize {
                            let len = 1024.min(sr as usize - pos2);
                            e.render(&mut buf[..len]);
                            for &s in &buf[..len] {
                                peak = peak.max(s.abs());
                            }
                            pos2 += len;
                        }
                        if peak > worst.0 {
                            worst = (peak, format!("trim={trim} trem={trem} spk={spk} mlp={mlp}"));
                        }
                    }
                }
            }
        }
        worst
    }

    /// At 44.1 kHz the output passes the 2x decimator. Its response to a rail-clipped edge
    /// overshoots the flat top (a bandlimited clipped waveform always does; a true-peak meter
    /// shows the same), by more the richer the clipped waveform's upper harmonics. Measured:
    /// 1.0089 (2026-09-23), 1.0200 with the overlap pickup law and the provisional reed swing
    /// (2026-09-26) — while the same probe without the decimator reads exactly 1.0000
    /// (`test_output_never_exceeds_full_scale_without_decimator`), so nothing else adds level.
    #[test]
    fn test_output_never_exceeds_full_scale_across_settings() {
        let worst = worst_peak_across_settings(44_100.0);
        assert!(
            worst.0 <= 1.025,
            "output exceeded full scale beyond the decimator margin: peak {:.4} at {} — a \
             downstream stage adds level or the mapping no longer equals the rail \
             (tables::FULL_SCALE_VOLTS)",
            worst.0,
            worst.1
        );
        println!(
            "worst-case peak across settings: {:.4} at {}",
            worst.0, worst.1
        );
    }

    /// The strict form of the invariant: at 96 kHz the engine does not oversample, so there is
    /// no decimator overshoot and the output must not exceed the rail at all.
    #[test]
    fn test_output_never_exceeds_full_scale_without_decimator() {
        let worst = worst_peak_across_settings(96_000.0);
        assert!(
            worst.0 <= 1.001,
            "output exceeded full scale with no decimator in the path: peak {:.4} at {} — a \
             stage adds level (tables::FULL_SCALE_VOLTS)",
            worst.0,
            worst.1
        );
    }

    /// Where does a rail-clipped chord pick up its overshoot? Compare the
    /// post-amp buffer (after the decimator, before the speaker) with the
    /// final output, at 44.1 kHz (oversampled) and 88.2 kHz (no decimator).
    #[test]
    #[ignore = "diagnostic probe"]
    fn full_scale_overshoot_probe() {
        for &sr in &[44_100.0f64, 88_200.0] {
            let mut e = WurliEngine::new(sr);
            e.ensure_buffer_capacity(1024);
            e.set_volume(1.0);
            e.set_reed_bar_trim(0.0);
            e.set_tremolo_depth(1.0);
            e.set_speaker_character(0.0);
            e.set_mlp_enabled(false);
            e.set_noise_enabled(false);
            e.warm_up();
            let mut buf = vec![0.0f32; 1024];
            for _ in 0..6 {
                e.render(&mut buf);
            }
            let delay = (sr as usize) * 162 / 1000;
            let mut pos = 0;
            while pos < delay {
                let len = 1024.min(delay - pos);
                e.render(&mut buf[..len]);
                pos += len;
            }
            for &n in &[48u8, 55, 60, 63, 67, 70] {
                e.note_on(n, 1.0);
            }
            let (mut pk_amp, mut pk_out) = (0.0f64, 0.0f32);
            let mut pos2 = 0;
            let total = sr as usize;
            while pos2 < total {
                let len = 1024.min(total - pos2);
                e.render(&mut buf[..len]);
                for &v in &e.out_buf[..len] {
                    pk_amp = pk_amp.max(v.abs());
                }
                for &v in &buf[..len] {
                    pk_out = pk_out.max(v.abs());
                }
                pos2 += len;
            }
            println!(
                "sr {sr}: post-amp(+decimator) peak {pk_amp:.4}, output peak {pk_out:.4} (speaker bypass adds {:+.2} dB)",
                20.0 * (pk_out as f64 / pk_amp).log10()
            );
        }
    }

    #[test]
    fn test_user_volume_follows_pot_law() {
        // VOLUME NETWORK (2026-09-23): user volume is the drawn pot between
        // preamp and power amp (tables::volume_pot_gain), so the output must
        // follow that law in the amp's linear region. Compare vol=0.75 and
        // vol=1.0 (both drive the amp above its crossover notch and below
        // its clip knee for a single note); the peak ratio must match the
        // pot-network gain ratio. If this regresses, either the network or
        // the post-amp path picked up an extra volume dependence.
        let render_at = |vol: f64| -> f32 {
            let mut e = engine();
            e.ensure_buffer_capacity(1024);
            e.set_volume(vol);
            e.set_tremolo_depth(0.0);
            e.set_speaker_character(0.0);
            e.set_mlp_enabled(true);
            e.set_noise_enabled(false);
            let mut warmup = vec![0.0f32; 1024];
            for _ in 0..6 {
                e.render(&mut warmup);
            }
            e.note_on(60, 0.95);
            let total = (44_100.0 * 0.5) as usize;
            let mut out = Vec::with_capacity(total);
            let mut buf = vec![0.0f32; 1024];
            let mut pos = 0;
            while pos < total {
                let len = 1024.min(total - pos);
                e.render(&mut buf[..len]);
                out.extend_from_slice(&buf[..len]);
                pos += len;
            }
            out.iter().fold(0.0f32, |a, &s| a.max(s.abs()))
        };
        let p_075 = render_at(0.75);
        let p_10 = render_at(1.0);
        let ratio = (p_10 / p_075) as f64;
        let r11 = tables::R11_REED_BAR_VOLUME_DEFAULT;
        let expected = tables::volume_pot_gain(1.0, r11) / tables::volume_pot_gain(0.75, r11);
        // ±6 % slack: MLP determinism and the amp's
        // residual level dependence (crossover notch, shelf) at these drives.
        assert!(
            (ratio / expected - 1.0).abs() < 0.06,
            "user volume should follow the pot network: ratio {ratio:.3}, expected \
             {expected:.3} (p_075={p_075:.4}, p_10={p_10:.4}) — see tables::volume_pot_gain."
        );
    }

    #[test]
    fn test_higher_velocity_louder() {
        let mut e = engine();
        e.set_volume(0.5);
        // pp render
        e.note_on(60, 0.2);
        let mut soft = vec![0.0f32; 4096];
        e.render(&mut soft);
        e.reset();
        // ff render
        e.note_on(60, 1.0);
        let mut loud = vec![0.0f32; 4096];
        e.render(&mut loud);

        let soft_rms: f64 =
            (soft.iter().map(|s| (*s as f64).powi(2)).sum::<f64>() / soft.len() as f64).sqrt();
        let loud_rms: f64 =
            (loud.iter().map(|s| (*s as f64).powi(2)).sum::<f64>() / loud.len() as f64).sqrt();
        assert!(
            loud_rms > soft_rms,
            "ff RMS ({loud_rms}) should exceed pp RMS ({soft_rms})"
        );
    }

    // ── Note clamping ───────────────────────────────────────────────────

    #[test]
    fn test_note_clamps_to_valid_range() {
        let mut e = engine();
        e.note_on(0, 0.8); // below MIDI_LO
        e.note_on(127, 0.8); // above MIDI_HI
        assert_eq!(
            e.held_voice_count(),
            2,
            "both notes clamped, both allocated"
        );
    }

    // ── Sustain pedal ───────────────────────────────────────────────────

    #[test]
    fn test_sustain_pedal_release_triggers_damping() {
        // Hold pedal, play note, release key (→ Sustained), release pedal
        // (→ Releasing). Voice should be damping, not still ringing.
        let mut e = engine();
        e.set_sustain(true);
        e.note_on(60, 0.8);
        e.note_off(60);
        assert_eq!(e.sustained_voice_count(), 1);
        e.set_sustain(false);
        // Sustained voice transitions to Releasing on pedal release.
        assert_eq!(e.sustained_voice_count(), 0);
        assert_eq!(e.count_voices_in_state(VoiceState::Releasing), 1);
    }

    #[test]
    fn test_sustain_held_voices_still_render() {
        // After pedal-up triggers damping, the voice should still produce
        // output during the release tail (not abruptly silenced).
        let mut e = engine();
        e.set_sustain(true);
        e.note_on(60, 0.8);
        let mut buf = vec![0.0f32; 1024];
        e.render(&mut buf);
        e.note_off(60);
        e.render(&mut buf);
        e.set_sustain(false);
        e.render(&mut buf);
        let energy: f64 = buf.iter().map(|s| (*s as f64).powi(2)).sum();
        assert!(energy > 0.0, "voice silenced too soon after pedal release");
    }

    #[test]
    fn test_no_sustain_normal_note_off() {
        // Pedal up: note_off transitions Held → Releasing immediately.
        let mut e = engine();
        e.note_on(60, 0.8);
        e.note_off(60);
        assert_eq!(e.held_voice_count(), 0);
        assert_eq!(e.count_voices_in_state(VoiceState::Releasing), 1);
    }

    #[test]
    fn test_voice_stealing_prefers_sustained_over_held() {
        // Fill all slots: half Held, half Sustained. Stealing should target
        // a Sustained slot first (less disruptive than a key-down note).
        let mut e = engine();
        e.set_sustain(true);
        for n in 0..(MAX_VOICES / 2) {
            e.note_on((36 + n) as u8, 0.8);
            e.note_off((36 + n) as u8); // → Sustained
        }
        for n in (MAX_VOICES / 2)..MAX_VOICES {
            e.note_on((36 + n) as u8, 0.8); // → Held
        }
        let sustained_before = e.sustained_voice_count();
        let held_before = e.held_voice_count();
        assert_eq!(sustained_before + held_before, MAX_VOICES);

        e.note_on(127, 0.8); // forces a steal
        // The new voice replaces a Sustained slot; held count unchanged.
        assert_eq!(e.held_voice_count(), held_before + 1);
        assert_eq!(e.sustained_voice_count(), sustained_before - 1);
    }

    #[test]
    fn test_reattack_releases_sustained_same_note() {
        // Real 200A has one reed per pitch — re-striking a sustained note
        // releases the old voice rather than accumulating duplicates.
        let mut e = engine();
        e.set_sustain(true);
        e.note_on(60, 0.8);
        e.note_off(60); // → Sustained
        e.note_on(60, 0.8); // re-attack same note
        assert_eq!(
            e.count_voices_with_note_in_state(60, VoiceState::Sustained),
            0,
            "old sustained voice should be released on re-attack"
        );
        assert_eq!(
            e.count_voices_with_note_in_state(60, VoiceState::Held),
            1,
            "new voice should be Held"
        );
    }

    #[test]
    fn test_pedal_up_only_releases_sustained_not_held() {
        // Pedal release should ONLY affect Sustained voices; voices the
        // player is still holding stay Held.
        let mut e = engine();
        e.set_sustain(true);
        e.note_on(60, 0.8);
        e.note_off(60); // → Sustained
        e.note_on(64, 0.8); // → Held (key still down)
        assert_eq!(e.sustained_voice_count(), 1);
        assert_eq!(e.held_voice_count(), 1);
        e.set_sustain(false);
        assert_eq!(e.sustained_voice_count(), 0);
        assert_eq!(e.held_voice_count(), 1, "held voice must survive pedal up");
    }

    #[test]
    fn test_all_notes_off_releases_held_and_sustained_keeps_pedal() {
        let mut e = engine();
        e.set_sustain(true);
        e.note_on(60, 0.8);
        e.note_off(60); // → Sustained
        e.note_on(64, 0.8); // → Held
        e.note_on(64, 0.8); // re-strike without note-off: a second Held voice on 64
        assert_eq!(e.held_voice_count(), 2);
        assert_eq!(e.sustained_voice_count(), 1);

        e.all_notes_off();
        assert_eq!(e.held_voice_count(), 0);
        assert_eq!(e.sustained_voice_count(), 0);
        assert_eq!(e.count_voices_in_state(VoiceState::Releasing), 3);
        assert!(e.is_sustain_held(), "all_notes_off must not lift the pedal");

        // With the pedal still down, a new note sustains after its key-off.
        e.note_on(67, 0.8);
        e.note_off(67);
        assert_eq!(e.sustained_voice_count(), 1);
    }

    #[test]
    fn test_release_all_keys_respects_the_pedal() {
        let mut e = engine();
        e.set_sustain(true);
        e.note_on(60, 0.8);
        e.note_off(60); // → Sustained
        e.note_on(64, 0.8);
        e.note_on(64, 0.8); // two Held on 64
        e.release_all_keys();
        assert_eq!(e.held_voice_count(), 0);
        assert_eq!(
            e.sustained_voice_count(),
            3,
            "pedal down: all keep sounding"
        );
        e.set_sustain(false);
        assert_eq!(e.sustained_voice_count(), 0);
        assert_eq!(e.count_voices_in_state(VoiceState::Releasing), 3);

        // Pedal up: lifted keys damp at once.
        e.note_on(67, 0.8);
        e.note_on(67, 0.8);
        e.release_all_keys();
        assert_eq!(e.held_voice_count(), 0);
        assert_eq!(e.sustained_voice_count(), 0);
    }

    #[test]
    fn test_all_notes_off_releases_clamped_stack() {
        // Out-of-range notes clamp onto the end keys, so several Held voices
        // share one note; note_off would release only the oldest of them.
        let mut e = engine();
        for n in [21u8, 24, 28, 30] {
            e.note_on(n, 0.8); // all clamp onto MIDI_LO
        }
        assert_eq!(e.held_voice_count(), 4);
        e.all_notes_off();
        assert_eq!(e.held_voice_count(), 0);
        assert_eq!(e.count_voices_in_state(VoiceState::Releasing), 4);
    }

    #[test]
    fn test_choke_stops_every_voice_on_the_note_only() {
        let mut e = engine();
        e.set_sustain(true);
        e.note_on(60, 0.8);
        e.note_off(60); // → Sustained
        e.note_on(60, 0.8); // re-strike: the sustained 60 damps, a new Held 60
        e.note_on(64, 0.8); // Held, different note
        e.choke(60);
        assert_eq!(e.count_voices_in_state(VoiceState::Releasing), 0);
        assert_eq!(e.held_voice_count(), 1, "64 must keep sounding");
        assert!(
            e.voices
                .iter()
                .all(|s| s.state == VoiceState::Free || s.midi_note == 64)
        );
        assert!(e.is_sustain_held());
    }

    #[test]
    fn test_all_sound_off_frees_every_voice_and_fades_out() {
        let mut e = engine();
        e.ensure_buffer_capacity(1024);
        e.set_sustain(true);
        for n in [48u8, 60, 64, 67] {
            e.note_on(n, 1.0);
        }
        e.note_off(48); // → Sustained
        let mut buf = vec![0.0f32; 1024];
        e.render(&mut buf); // let the notes speak
        e.all_sound_off();
        assert_eq!(e.active_voice_count(), 0, "every slot is free at once");
        assert!(e.is_sustain_held(), "the pedal state is left alone");

        // The 5 ms fade means the next block starts from where the notes were,
        // not from a step to zero, and the voices are gone within the fade.
        let fade = (44_100.0f64 * 0.005) as usize;
        let mut out = vec![0.0f32; 4096];
        e.render(&mut out);
        assert!(
            e.voices.iter().all(|s| s.steal_voice.is_none()),
            "fades complete"
        );
        let tail_start = fade + 2048; // well after the fade, past the chain's short tail
        let tail_peak = out[tail_start..].iter().fold(0.0f32, |m, v| m.max(v.abs()));
        let head_peak = out[..fade].iter().fold(0.0f32, |m, v| m.max(v.abs()));
        assert!(head_peak > 0.0, "the fade starts from sounding audio");
        assert!(
            tail_peak < head_peak * 0.01,
            "sound must stop: tail peak {tail_peak} vs head {head_peak}"
        );
    }

    fn render_samples(e: &mut WurliEngine, n: usize) -> Vec<f32> {
        let mut out = vec![0.0f32; n];
        for chunk in out.chunks_mut(512) {
            e.render(chunk);
        }
        out
    }

    #[test]
    fn test_hammer_contact_latches_at_note_on() {
        let strike = |before: Option<f64>, after: Option<f64>| {
            let mut e = engine();
            e.ensure_buffer_capacity(512);
            if let Some(s) = before {
                e.set_hammer_contact_scale(s);
            }
            e.note_on(36, 1.0);
            if let Some(s) = after {
                e.set_hammer_contact_scale(s);
            }
            render_samples(&mut e, 8192)
        };
        let ship = strike(None, None);
        assert_eq!(strike(Some(1.0), None), ship, "1.0 is the shipping voicing");
        assert_eq!(
            strike(None, Some(0.5)),
            ship,
            "a sounding note keeps its strike"
        );
        assert_ne!(
            strike(Some(0.5), None),
            ship,
            "the next strike uses the new pad"
        );
    }

    #[test]
    fn test_damper_scale_reaches_held_voices_at_note_off() {
        let release_tail = |scale: f64| {
            let mut e = engine();
            e.ensure_buffer_capacity(512);
            e.note_on(48, 1.0);
            render_samples(&mut e, 4096);
            e.set_damper_scale(scale); // after note-on: must still apply at note-off
            e.note_off(48);
            let out = render_samples(&mut e, 8192);
            out[2048..].iter().map(|v| (*v as f64).powi(2)).sum::<f64>()
        };
        let (weak, ship, firm) = (release_tail(0.25), release_tail(1.0), release_tail(4.0));
        assert!(weak > ship && ship > firm, "{weak} > {ship} > {firm}");
    }

    #[test]
    fn test_reset_clears_sustain_state() {
        let mut e = engine();
        e.set_sustain(true);
        e.note_on(60, 0.8);
        e.note_off(60);
        e.reset();
        assert!(!e.is_sustain_held(), "sustain flag must clear on reset");
        assert_eq!(e.active_voice_count(), 0);
    }

    #[test]
    fn test_note_off_for_nonexistent_note_is_noop() {
        let mut e = engine();
        e.note_on(60, 0.8);
        e.note_off(72); // never on
        assert_eq!(
            e.held_voice_count(),
            1,
            "wrong-note off should not damage state"
        );
    }

    // ── NaN / divergence guards ─────────────────────────────────────────

    #[test]
    fn test_volume_zero_and_back_no_nan() {
        // Regression: sweeping volume to zero and back caused NaN that
        // crashed PipeWire. The engine smoother + chain must be NaN-free.
        let mut e = engine();
        e.note_on(60, 0.8);
        let mut buf = vec![0.0f32; 512];
        for _ in 0..4 {
            e.set_volume(0.0);
            e.render(&mut buf);
            e.set_volume(0.5);
            e.render(&mut buf);
        }
        assert!(
            buf.iter().all(|s| s.is_finite()),
            "non-finite sample leaked"
        );
    }

    #[test]
    fn test_no_catastrophic_output_spikes_under_continuous_play() {
        // Regression for the melange power-amp divergence guard: under
        // continuous chord transitions the solver intermittently failed to
        // converge and produced +20 dBFS spikes. Engine wraps the same
        // power-amp adapter so the guard still applies.
        //
        // Threshold: +14 dBFS. Normal chord-ff content stays below full scale
        // at the engine's rail reference (the worst case is ~0.52, see
        // test_output_never_exceeds_full_scale_across_settings) — the guard sits well above that and well below the +20 dBFS
        // catastrophic value the divergence guard exists to prevent.
        let mut e = engine();
        let chords: [[u8; 3]; 4] = [[60, 64, 67], [62, 65, 69], [64, 67, 71], [65, 69, 72]];
        let block = 256;
        let blocks_per_segment = 86; // ~0.5 s per chord at 44.1 k
        let mut buf = vec![0.0f32; block];
        let mut peak = 0.0f32;
        for (i, chord) in chords.iter().cycle().take(8).enumerate() {
            for n in chord {
                e.note_on(*n, 1.0);
            }
            for _ in 0..blocks_per_segment {
                e.render(&mut buf);
                peak = peak.max(buf.iter().map(|s| s.abs()).fold(0.0f32, f32::max));
            }
            for n in chord {
                e.note_off(*n);
            }
            // Small drain between chords
            if i % 2 == 1 {
                for _ in 0..5 {
                    e.render(&mut buf);
                }
            }
        }
        let peak_dbfs = 20.0 * peak.max(1e-12).log10();
        assert!(
            peak_dbfs < 14.0,
            "peak {peak_dbfs:.2} dBFS exceeds +14 dBFS divergence-guard threshold"
        );
    }

    // ── Sample-rate / buffer-size changes ───────────────────────────────

    #[test]
    fn test_sound_after_sample_rate_change() {
        let mut e = engine();
        e.set_sample_rate(48_000.0);
        e.note_on(60, 0.8);
        let mut buf = vec![0.0f32; 1024];
        e.render(&mut buf);
        let energy: f64 = buf.iter().map(|s| (*s as f64).powi(2)).sum();
        assert!(energy > 0.0, "no output after sample-rate change");
    }

    #[test]
    fn test_buffer_capacity_grows_to_render() {
        // Engine should auto-grow its internal scratch buffers when render
        // is called with a larger output slice than initial allocation.
        let mut e = engine();
        e.note_on(60, 0.8);
        let mut big_buf = vec![0.0f32; 16_384]; // > MAX_BLOCK_SIZE default
        e.render(&mut big_buf);
        assert!(big_buf.iter().all(|s| s.is_finite()));
    }

    // ── Tremolo smoothing ────────────────────────────────────────────────

    #[test]
    fn test_tremolo_smoother_does_not_pin_depth_to_zero() {
        // Regression for the legacy nih-plug smoother bug where
        // smoothed.next() returned 0 forever before host init. Engine
        // smoother snaps to its construction default, so even without an
        // explicit set_tremolo_depth() call the depth is the constructor's
        // value (0.5), and a 4 s render must produce audible AM.
        let mut e = engine();
        e.note_on(60, 0.9);
        let sr = 44_100_usize;
        let total = sr * 4;
        let block = 256;
        let mut samples = Vec::with_capacity(total);
        let mut buf = vec![0.0f32; block];
        for _ in 0..(total / block) {
            e.render(&mut buf);
            samples.extend_from_slice(&buf);
        }
        // RMS envelope over 20 ms windows, ignoring the first 0.5 s.
        let win = sr / 50;
        let skip = 25;
        let n_wins = samples.len() / win;
        let mut env_db = Vec::with_capacity(n_wins);
        for i in skip..n_wins {
            let s = i * win;
            let rms = (samples[s..s + win]
                .iter()
                .map(|x| (*x as f64).powi(2))
                .sum::<f64>()
                / win as f64)
                .sqrt();
            env_db.push(20.0 * (rms + 1e-12).log10());
        }
        let env_min = env_db.iter().cloned().fold(f64::INFINITY, f64::min);
        let env_max = env_db.iter().cloned().fold(f64::NEG_INFINITY, f64::max);
        let swing = env_max - env_min;
        assert!(
            swing > 3.0,
            "Tremolo should produce > 3 dB RMS swing at default depth 0.5: got {swing:.2} dB"
        );
    }

    /// Power-amp drive-headroom probe (Phase-2 closing measurement).
    ///
    /// Reports peak and RMS of the signal actually presented to the power amp
    /// (`preamp_out * volume_pot_gain(vol)`, at vol 0.5 and 1.0) so it can be
    /// compared against the amp's linearity envelope. Reference points:
    ///   * behavioural amp closed-loop gain 68.93x, rails at 22 V
    ///     => hard rail clip at 22 / 68.93 = 319 mV input
    ///   * SPICE reference: THD crosses 1% near 295-300 mV input, razor cliff above
    ///
    /// Since 2026-09-23 the drive follows the drawn volume network, so the
    /// probe runs at the default pot position and at full.
    #[test]
    #[ignore = "diagnostic probe"]
    fn power_amp_drive_headroom_probe() {
        let sr = 44_100.0;
        for vol in [0.8f64, 1.0] {
            println!("  --- pot position {vol} (R-11 at its default) ---");
            let mk = || {
                let mut e = WurliEngine::new(sr);
                e.ensure_buffer_capacity(1024);
                e.set_volume(vol);
                e.set_tremolo_depth(1.0);
                e.set_speaker_character(0.0);
                e.set_mlp_enabled(true);
                e.set_noise_enabled(false);
                e.warm_up();
                e
            };
            let run = |e: &mut WurliEngine, total: usize| {
                let mut buf = vec![0.0f32; 1024];
                let mut pos = 0;
                while pos < total {
                    let len = 1024.min(total - pos);
                    e.render(&mut buf[..len]);
                    pos += len;
                }
            };
            println!("  stimulus            peak mV    RMS mV   % of 319 mV clip");
            // (a) single ff notes across the register
            for note in [36u8, 48, 60, 72, 84] {
                let mut best = (0.0f64, 0.0f64);
                for delay_ms in [0usize, 44, 89, 133, 162] {
                    let mut e = mk();
                    run(&mut e, (sr as usize) * delay_ms / 1000);
                    e.drive_peak = 0.0;
                    e.drive_sumsq = 0.0;
                    e.drive_n = 0;
                    e.note_on(note, 0.95);
                    run(&mut e, sr as usize);
                    let rms = (e.drive_sumsq / e.drive_n as f64).sqrt();
                    if e.drive_peak > best.0 {
                        best = (e.drive_peak, rms);
                    }
                }
                println!(
                    "  note {note:>3} ff       {:8.1}  {:8.1}   {:6.1}%",
                    best.0 * 1000.0,
                    best.1 * 1000.0,
                    best.0 / 0.319 * 100.0
                );
            }
            // (b) worst-phase ff chord — same stimulus as the peak invariant
            let mut best = (0.0f64, 0.0f64);
            for delay_ms in [0usize, 44, 89, 133, 162] {
                let mut e = mk();
                run(&mut e, (sr as usize) * delay_ms / 1000);
                e.drive_peak = 0.0;
                e.drive_sumsq = 0.0;
                e.drive_n = 0;
                for &n in &[48u8, 55, 60, 63, 67, 70] {
                    e.note_on(n, 0.95);
                }
                run(&mut e, sr as usize);
                let rms = (e.drive_sumsq / e.drive_n as f64).sqrt();
                if e.drive_peak > best.0 {
                    best = (e.drive_peak, rms);
                }
            }
            println!(
                "  chord ff worst-ph  {:8.1}  {:8.1}   {:6.1}%",
                best.0 * 1000.0,
                best.1 * 1000.0,
                best.0 / 0.319 * 100.0
            );
        }
    }

    /// Behavioural power-amp linearity envelope — where does its nonlinearity
    /// actually engage? Sine sweep straight into `PowerAmp`, THD via DFT.
    /// Reference: SPICE says the real amp crosses 1% THD near 295-300 mV in.
    #[test]
    #[ignore = "diagnostic probe"]
    fn power_amp_linearity_envelope_probe() {
        use crate::power_amp::PowerAmp;
        let sr = 88_200.0;
        let n = 8192usize;
        // COHERENT analysis frequency: the 4096-sample window must hold an
        // integer number of cycles, else leakage from H1 sets a constant
        // apparent-THD floor that masks the real level dependence entirely
        // (an incoherent 220 Hz reads a flat 3.38% from 1 mV to 330 mV).
        let f = 10.0 * sr / (n as f64 / 2.0); // 215.33 Hz, exactly 10 cycles
        let thd_at = |amp_v: f64| {
            let mut pa = PowerAmp::new_at_sample_rate(sr);
            let mut y = vec![0.0f64; n];
            for i in 0..n {
                let t = i as f64 / sr;
                y[i] = pa.process(amp_v * (2.0 * std::f64::consts::PI * f * t).sin());
            }
            let w = &y[n / 2..];
            let mag = |k: f64| {
                let (mut re, mut im) = (0.0, 0.0);
                for (i, &v) in w.iter().enumerate() {
                    let ph = 2.0 * std::f64::consts::PI * k * i as f64 / sr;
                    re += v * ph.cos();
                    im -= v * ph.sin();
                }
                ((re / w.len() as f64).powi(2) + (im / w.len() as f64).powi(2)).sqrt()
            };
            let h1 = mag(f);
            let harm: f64 = (2..=8).map(|h| mag(h as f64 * f).powi(2)).sum();
            100.0 * harm.sqrt() / h1
        };
        println!("   input mV     THD %");
        for mv in [
            1.0f64, 5.0, 10.0, 20.0, 54.5, 100.0, 115.6, 150.0, 200.0, 250.0, 280.0, 295.0, 300.0,
            310.0, 319.0, 330.0,
        ] {
            println!("   {mv:8.1}  {:9.4}", thd_at(mv / 1000.0));
        }
    }
}
