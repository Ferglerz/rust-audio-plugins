//! Per-note parameter tables for Wurlitzer 200A reed modal synthesis.
//!
//! Derived from Euler-Bernoulli beam theory with tip mass (docs/research/reed-and-hammer-physics.md).
//! Range: MIDI 33 (A1) to MIDI 96 (C7) -- 64 reeds.
pub const NUM_MODES: usize = 7;
pub const MIDI_LO: u8 = 33;
pub const MIDI_HI: u8 = 96;

/// Base mode amplitudes calibrated against OBM Wurlitzer 200A recordings.
///
/// Original 1/ω_n scaling (Section 3.2) predicted [1.0, 0.160, 0.057, ...]
/// from ideal bare-beam impulse response. However, OBM onset-phase spectral
/// analysis reveals physical mode 2 is 20-37 dB weaker than predicted across
/// the full register. Real Wurlitzer reeds have solder tip mass, non-uniform
/// geometry, and hammer coupling that suppress upper modes far below the
/// Euler-Bernoulli ideal.
///
/// Calibration method: back-calculate mechanical mode 2/fundamental ratio
/// from OBM recordings by correcting for the pickup HPF at 2312 Hz. OBM
/// mid-range (D4) implies mechanical mode 2 at -43 dB vs model's -16 dB.
/// Upper modes scaled proportionally (1/ω_n ratios preserved).
///
/// Mode 2 reduced from 0.010 to 0.005 (-6 dB) to eliminate a metallic
/// "plink" in mid-register: at 6.267×f0 ≈ 1642 Hz (C4), mode 2 sits in
/// peak ear sensitivity and creates an inharmonic ring. At 0.005, mode 2
/// is -36 dB at the pickup output — below the audibility threshold for an
/// inharmonic partial. This is within the OBM calibration uncertainty (±5 dB).
///
/// The real 200A's "bark" comes primarily from the pickup's 1/(1-y)
/// nonlinearity generating H2 at 2×fundamental, NOT from physical mode 2
/// oscillation at ~6.3×fundamental.
pub const BASE_MODE_AMPLITUDES: [f64; NUM_MODES] =
    [1.0, 0.005, 0.0035, 0.0018, 0.0011, 0.0007, 0.0005];

/// MIDI note number to fundamental frequency (Hz), A440 tuning.
pub fn midi_to_freq(midi: u8) -> f64 {
    440.0 * f64::powf(2.0, (midi as f64 - 69.0) / 12.0)
}

/// Estimated tip mass ratio mu for a given MIDI note.
///
/// Anchor points from Section 2.6 eigenvalue analysis:
///   MIDI 33 (A1, reed 1):  mu ~ 0.10  (heavy solder on long bass reed)
///   MIDI 52 (E3, reed 20): mu ~ 0.00  (bare beam close to target pitch)
///   MIDI 62 (D4, reed 30): mu ~ 0.00  (mid-register, minimal solder)
///   MIDI 74 (D5, reed 42): mu ~ 0.02  (some solder needed)
///   MIDI 96 (C7, reed 64): mu ~ 0.01  (minimal, short ground reed)
///
/// Linear interpolation between anchors.
pub fn tip_mass_ratio(midi: u8) -> f64 {
    let m = midi as f64;
    let anchors: &[(f64, f64)] = &[
        (33.0, 0.10),
        (52.0, 0.00),
        (62.0, 0.00),
        (74.0, 0.02),
        (96.0, 0.01),
    ];

    if m <= anchors[0].0 {
        return anchors[0].1;
    }
    if m >= anchors[anchors.len() - 1].0 {
        return anchors[anchors.len() - 1].1;
    }

    for i in 0..anchors.len() - 1 {
        let (x0, y0) = anchors[i];
        let (x1, y1) = anchors[i + 1];
        if m <= x1 {
            let t = (m - x0) / (x1 - x0);
            return y0 + t * (y1 - y0);
        }
    }
    0.0
}

/// Eigenvalues beta_n for a cantilever beam with tip mass ratio mu.
///
/// From Section 2.5 eigenvalue table. Uses linear interpolation on the eigenvalue
/// solutions of: 1 + cos(beta)cosh(beta) + beta*mu*(cos(beta)sinh(beta) - sin(beta)cosh(beta)) = 0
///
/// Returns eigenvalues for modes 1-7.
fn eigenvalues(mu: f64) -> [f64; NUM_MODES] {
    struct EigRow {
        mu: f64,
        betas: [f64; NUM_MODES],
    }

    let table = [
        EigRow {
            mu: 0.00,
            betas: [1.8751, 4.6941, 7.8548, 10.9955, 14.1372, 17.2788, 20.4204],
        },
        EigRow {
            mu: 0.01,
            betas: [1.8584, 4.6849, 7.8504, 10.9930, 14.1356, 17.2776, 20.4195],
        },
        EigRow {
            mu: 0.05,
            betas: [1.7920, 4.6477, 7.8316, 10.9830, 14.1288, 17.2726, 20.4158],
        },
        EigRow {
            mu: 0.10,
            betas: [1.7227, 4.6024, 7.8077, 10.9700, 14.1198, 17.2660, 20.4110],
        },
        EigRow {
            mu: 0.15,
            betas: [1.6625, 4.5618, 7.7859, 10.9580, 14.1114, 17.2598, 20.4065],
        },
        EigRow {
            mu: 0.20,
            betas: [1.6097, 4.5254, 7.7659, 10.9470, 14.1036, 17.2540, 20.4023],
        },
        EigRow {
            mu: 0.30,
            betas: [1.5201, 4.4620, 7.7310, 10.9280, 14.0894, 17.2434, 20.3946],
        },
        EigRow {
            mu: 0.50,
            betas: [1.3853, 4.3601, 7.6745, 10.8970, 14.0650, 17.2252, 20.3814],
        },
    ];

    let mu_clamped = mu.clamp(0.0, 0.50);

    // Find the interval [lo, hi] bracketing mu_clamped
    let lo = table
        .iter()
        .rposition(|row| row.mu <= mu_clamped)
        .unwrap_or(0);
    let hi = (lo + 1).min(table.len() - 1);

    let t = if table[hi].mu > table[lo].mu {
        (mu_clamped - table[lo].mu) / (table[hi].mu - table[lo].mu)
    } else {
        0.0
    };

    std::array::from_fn(|i| table[lo].betas[i] + t * (table[hi].betas[i] - table[lo].betas[i]))
}

/// Mode frequency ratios f_n/f_1 for a cantilever beam with tip mass ratio mu.
///
/// Returns ratios for modes 1-7 (mode 1 is always 1.0). Computed from
/// eigenvalues: ratio_n = (beta_n / beta_1)^2.
pub fn mode_ratios(mu: f64) -> [f64; NUM_MODES] {
    let betas = eigenvalues(mu);
    let b1_sq = betas[0] * betas[0];
    std::array::from_fn(|i| (betas[i] * betas[i]) / b1_sq)
}

/// Reed length in mm for a given MIDI note.
///
/// Two-segment linear formula from docs/research/reed-and-hammer-physics.md (Section 1.3):
///   Reed number n = midi - 32 (MIDI 33 = reed 1, MIDI 96 = reed 64)
///   Bass (n=1-20):   L = 3.0 - n/20 inches
///   Treble (n=21-64): L = 2.0 - (n-20)/44 inches
pub fn reed_length_mm(midi: u8) -> f64 {
    let n = (midi as f64 - 32.0).clamp(1.0, 64.0);
    let inches = if n <= 20.0 {
        3.0 - n / 20.0
    } else {
        2.0 - (n - 20.0) / 44.0
    };
    inches * 25.4
}

/// Reed blank width and thickness for a given MIDI note.
///
/// Returns (width_mm, thickness_mm) based on 200A series blank dimensions
/// from docs/research/reed-and-hammer-physics.md Section 1.2.
///
/// Five blanks with distinct widths; thickness uses 200A values (thicker than
/// 200-series) per Vintage Vibe case study: bass 0.026", mid/treble 0.034".
/// The 200A's thicker reeds produce a "smoother, rounder, mellower tone"
/// and reduce displacement for the same hammer force (less bark at extreme bass).
/// The thickness transition is smoothed over 10 semitones (reeds 16-26, MIDI 48-58)
/// to model the gradual grinding taper at blank boundaries.
pub(crate) fn reed_blank_dims(midi: u8) -> (f64, f64) {
    let reed = (midi as i32 - 32).clamp(1, 64) as u8;

    // Width in inches — steps between blanks
    let width_inch = if reed <= 14 {
        0.151 // Blank 1: reeds 1-14
    } else if reed <= 20 {
        0.127 // Blank 2: reeds 15-20
    } else if reed <= 42 {
        0.121 // Blank 3: reeds 21-42
    } else if reed <= 50 {
        0.111 // Blank 4: reeds 43-50
    } else {
        0.098 // Blank 5: reeds 51-64
    };

    // Thickness in inches — 200A values (thicker than 200-series 0.020/0.031)
    // Smooth transition from bass (0.026") to mid/treble (0.034")
    let thickness_inch = if reed <= 16 {
        0.026
    } else if reed <= 26 {
        // 10-semitone crossfade: reeds 16-26 (MIDI 48-58)
        let t = (reed as f64 - 16.0) / 10.0;
        0.026 + t * (0.034 - 0.026)
    } else {
        0.034
    };

    (width_inch * 25.4, thickness_inch * 25.4)
}

/// Beam tip compliance: L³ / (w × t³).
///
/// Higher compliance = more physical tip deflection for a given hammer force.
/// Bass reeds (long, thin) have ~25× the compliance of treble reeds (short, thick).
/// This determines how much the reed actually moves relative to the pickup gap,
/// which controls the strength of the 1/(1-y) nonlinearity ("bark").
pub fn reed_compliance(midi: u8) -> f64 {
    let l = reed_length_mm(midi);
    let (w, t) = reed_blank_dims(midi);
    (l * l * l) / (w * t * t * t)
}

/// Per-note displacement scale for the pickup nonlinearity.
///
/// Derived from beam compliance: stiffer treble reeds deflect less → less bark.
/// Exponent 0.75 gives steeper bass-to-treble gradient than sqrt(0.5), needed
/// to match OBM's ~10:1 H2/H1 ratio range (D3 bark ~0.5 vs Bb6 clean ~0.06).
///
/// Physical note: the 200A's actual rest gap d₀ between reed and pickup has
/// never been published — factory records destroyed 1988, no service manual
/// or patent specifies it for this model. DISPLACEMENT_SCALE absorbs this
/// unknown. Calibrated by ear + measurement against a moving baseline chain;
/// not a physics claim. When the chain changes, DS gets re-calibrated to
/// restore the previous effective working point.
///
/// Apr 2026 retune: after Phase 2 (melange power amp), Phase 4 (full
/// Gummel-Poon 2N5089 junction caps), and the Apr tremolo depth-curve fix,
/// the effective working point had drifted cooler. Raised DS_AT_C4 0.75 → 0.85
/// and DS_CLAMP upper 0.82 → 0.88 to recover ~+1 dB H2/H1 across register
/// without pushing y_peak past ~0.90 (still safely below PICKUP_MAX_Y=0.98).
/// Measured with `preamp-bench calibrate`; see `memory/calibration-history.md`.
///
/// Approximate post-retune values across the keyboard:
///   A1 (MIDI 33): 0.88  (clamped — heavy bass bark/growl)
///   D3 (MIDI 50): 0.88  (clamped — solid bark)
///   C4 (MIDI 60): 0.85  (reference, strong bark)
///   D5 (MIDI 74): 0.59  (moderate bark)
///   D6 (MIDI 86): 0.45  (lighter)
///   C7 (MIDI 96): 0.24  (clean, bell-like)
///
/// ## 2026-09-14 re-fit for the pickup modulation-depth restructure
///
/// `DS_AT_C4` **0.85 → 0.73**, `DS_CLAMP` upper **0.95 → 0.90**
/// (`DS_EXPONENT` unchanged at 0.75).
///
/// DS now means what its name says. The previous pickup model modulated the
/// whole plate node as `1/(1-y)` — 80x the physical depth — and DS was silently
/// absorbing the ratio; `pickup.rs` carries the derivation. With the
/// nonlinearity moved into the source term where it belongs, the same y
/// produces a much stronger and (correctly) frequency-independent harmonic
/// series, so the old DS over-drove it.
///
/// **`DS_CLAMP` upper 0.95 → 0.90** is the better-determined of the two: two
/// independent criteria land on it. (i) It puts C2 ff H2/H1 at 107.8% against
/// the pre-restructure branch's 109.5% — a 0.14 dB match on the bass-ladder
/// gate. (ii) It makes the C2 ff harmonic ladder track the pre-revision
/// reference (the one the perceptual review blessed as real-200A behaviour) to
/// **0.89 dB RMS across H2-H8**, versus 4.97 dB at the old 0.95 and 4.34 dB at
/// 0.86. A gap fraction of 0.95 — reed within 5% of touching — was survivable
/// when the nonlinearity was weak per unit y; with the correct one it is not.
///
/// **`DS_AT_C4` 0.85 → 0.73 → back to 0.85** (2026-09-14, Task D). The 0.73 step
/// was a level-budget stopgap taken while `POST_SPEAKER_GAIN_DB` was ringfenced;
/// with PSG free to move, DS returns to its ear-blessed value and PSG absorbs
/// the level instead. See the tradeoff curve on `POST_SPEAKER_GAIN_DB`.
///
/// At 0.85, C4 ff pickup H2/H1 is **73.0%** — H2 lands within 0.0 dB of the
/// pre-revision build at the same note (both +0.2 dB rel H1) — and the C4
/// velocity span recovers to **44.75 dB** against pre-revision's 43.14 dB.
///
/// ⚠ **`DS_AT_C4` is now the one true ear knob in this file.** It trades harmonic
/// richness against output level at roughly **1.5 dB of level per 1 dB of H2**,
/// and it is the constant to move first in a voicing session. `DS_CLAMP` pins
/// the bass independently (C2 is clamped at every DS in the useful range, so
/// the bass ladder does not move with this constant).
const DS_AT_C4: f64 = 0.85;
const DS_EXPONENT: f64 = 0.75;
const DS_CLAMP: (f64, f64) = (0.02, 0.90);

/// Runtime-overridable calibration parameters.
/// All fields default to the current hardcoded constants.
#[derive(Debug, Clone)]
pub struct CalibrationConfig {
    pub ds_at_c4: f64,
    pub ds_exponent: f64,
    pub ds_clamp: (f64, f64),
    pub target_db: f64,
    pub voicing_slope: f64,
    pub zero_trim: bool,
}

impl Default for CalibrationConfig {
    fn default() -> Self {
        Self {
            ds_at_c4: DS_AT_C4,
            ds_exponent: DS_EXPONENT,
            ds_clamp: DS_CLAMP,
            target_db: -35.0,
            voicing_slope: -0.04,
            zero_trim: false,
        }
    }
}

pub fn pickup_displacement_scale(midi: u8) -> f64 {
    pickup_displacement_scale_with_config(midi, &CalibrationConfig::default())
}

pub fn pickup_displacement_scale_with_config(midi: u8, cfg: &CalibrationConfig) -> f64 {
    let c = reed_compliance(midi);
    let c_ref = reed_compliance(60); // C4 reference
    let ds = cfg.ds_at_c4 * (c / c_ref).powf(cfg.ds_exponent);
    ds.clamp(cfg.ds_clamp.0, cfg.ds_clamp.1)
}

/// Cantilever beam mode shape phi_n(xi) with tip mass.
///
/// phi_n(xi) = cosh(beta*xi) - cos(beta*xi) - sigma*(sinh(beta*xi) - sin(beta*xi))
/// where sigma = (cosh(beta) + cos(beta)) / (sinh(beta) + sin(beta))
/// and xi = x/L (0=clamp, 1=tip).
fn mode_shape(beta: f64, xi: f64) -> f64 {
    let sigma = (beta.cosh() + beta.cos()) / (beta.sinh() + beta.sin());
    let bx = beta * xi;
    bx.cosh() - bx.cos() - sigma * (bx.sinh() - bx.sin())
}

/// Active pickup plate length in mm.
///
/// Estimated from Wurlitzer 200A pickup geometry — the electrode region that
/// effectively senses reed displacement. Conservative estimate; real plates
/// vary slightly by register.
const PLATE_ACTIVE_LENGTH_MM: f64 = 6.0;

/// Spatial coupling coefficients for pickup-reed interaction.
///
/// The pickup plate has finite length and integrates reed displacement over its
/// active region near the tip. Higher bending modes oscillate spatially — their
/// lobes partially cancel within the pickup window. This produces a spatial
/// low-pass filter that attenuates inharmonic modes relative to the fundamental.
///
/// Raw coupling: kappa_n = |integral of phi_n(xi) from (1-ell/L) to 1| / [ell/L * |phi_n(1)|]
///
/// **Normalized to mode 1**: the returned coefficients are kappa_n / kappa_1, so
/// mode 1 always returns 1.0. The absolute value of kappa_1 (0.83–0.94 depending
/// on register) is already absorbed into the pickup's displacement_scale, which
/// was calibrated against real-world bark levels assuming tip-displacement sensing.
/// What matters for mode suppression is the *differential* attenuation: how much
/// less the pickup senses mode n relative to mode 1.
#[allow(clippy::needless_range_loop)]
pub fn spatial_coupling_coefficients(mu: f64, reed_len_mm: f64) -> [f64; NUM_MODES] {
    let betas = eigenvalues(mu);
    let ell_over_l = (PLATE_ACTIVE_LENGTH_MM / reed_len_mm).clamp(0.0, 1.0);

    let mut kappa_raw = [0.0f64; NUM_MODES];

    // Simpson's rule with 32 subintervals
    const N_SIMPSON: usize = 32;
    let xi_start = 1.0 - ell_over_l;

    for mode in 0..NUM_MODES {
        let beta = betas[mode];
        let tip_val = mode_shape(beta, 1.0);

        if tip_val.abs() < 1e-30 || ell_over_l < 1e-12 {
            kappa_raw[mode] = 1.0; // Degenerate case: point pickup at tip
            continue;
        }

        // Simpson's rule: integral = (h/3) * [f(x0) + 4*f(x1) + 2*f(x2) + 4*f(x3) + ... + f(xN)]
        let h = ell_over_l / N_SIMPSON as f64;
        let mut sum = mode_shape(beta, xi_start) + mode_shape(beta, 1.0);

        for j in 1..N_SIMPSON {
            let xi = xi_start + j as f64 * h;
            let coeff = if j % 2 == 1 { 4.0 } else { 2.0 };
            sum += coeff * mode_shape(beta, xi);
        }

        let integral = sum * h / 3.0;
        // Absolute value: mode shapes can be negative at the tip for higher modes
        // (the sign just flips the phase, but coupling magnitude is what matters)
        let k = (integral / (ell_over_l * tip_val)).abs();
        kappa_raw[mode] = k.clamp(0.0, 1.0);
    }

    // Normalize to mode 1: the reed model outputs tip displacement, and
    // displacement_scale is calibrated for tip-referenced y. Applying raw kappa_1 < 1
    // would double-count the spatial averaging (once here, once in the calibrated scale).
    // Only the differential suppression (kappa_n / kappa_1) is meaningful.
    let k1 = kappa_raw[0];
    if k1 > 1e-30 {
        std::array::from_fn(|i| (kappa_raw[i] / k1).clamp(0.0, 1.0))
    } else {
        [1.0; NUM_MODES]
    }
}

/// Fundamental decay rate in dB/s for a given MIDI note.
///
/// Frequency power law calibrated against 10 clean OBM 200A decay rates
/// (excluding anomalous D6/F#6/D7): `decay = 0.005 * f^1.22`, floored at 3.0 dB/s.
///
/// Physical basis: corresponds to Q ∝ f^(-0.22) — a slight Q decrease with
/// frequency, consistent with thermoelastic (Zener) damping becoming more
/// significant for shorter, stiffer reeds. A constant-Q model (Q~1636) gives
/// exponent 1.0 (decay ∝ f); the slight upward correction captures the trend
/// in OBM data where treble reeds have modestly lower Q than bass.
///
/// Approximate values: F#3=3.0 (floor), D4=5.2, Bb4=8.5, F#5=16.0,
/// Bb5=21.1, C6=24.2 dB/s.
///
/// The 3.0 dB/s floor handles frequency-independent losses (clamping friction,
/// structural radiation, viscous air damping) that dominate for bass reeds
/// MIDI 33-48. OBM confirms bass decay rates are ~3 dB/s throughout octaves
/// 2-3, matching this floor.
const MIN_DECAY_RATE: f64 = 3.0;

pub fn fundamental_decay_rate(midi: u8) -> f64 {
    let f = midi_to_freq(midi);
    (0.005 * f.powf(1.22)).max(MIN_DECAY_RATE)
}

/// Per-mode decay rates in dB/s.
///
/// Super-linear damping model: decay_n = decay_1 * mode_ratio_n^p
///
/// Real steel reed damping is NOT constant-Q (p=1.0). Thermoelastic (Zener),
/// air radiation, and clamping losses all scale faster than linearly with
/// frequency, giving p ≈ 1.3–2.0 for steel cantilevers in air.
///
/// At p=2.0, mode 2 at C4 (1642 Hz) decays at ~326 dB/s, reaching -10 dB
/// within 9ms (~2.5 cycles). This confines the inharmonic partials (which
/// sit at non-integer ratios like 6.267× and sound "metallic") to the
/// first 2-3 cycles of the attack, matching real Wurlitzer behavior.
///
/// Previous value (1.5) allowed mode 2 to ring for ~77ms in mid-register,
/// creating an audible metallic "plink" at 1642 Hz — peak ear sensitivity.
/// The p=2.0 value better matches Zener thermoelastic theory (loss ∝ ω²).
///
/// Note: the constant is preserved for documentation; `mode_decay_rates()`
/// inlines `ratio * ratio` instead of `powf(2.0)` for performance.
pub const MODE_DECAY_EXPONENT: f64 = 2.0;

pub fn mode_decay_rates(midi: u8, ratios: &[f64; NUM_MODES]) -> [f64; NUM_MODES] {
    let base = fundamental_decay_rate(midi);
    // Inlined ratio² is cheaper than powf(MODE_DECAY_EXPONENT)
    std::array::from_fn(|i| base * ratios[i] * ratios[i])
}

/// Multi-harmonic RMS proxy for post-pickup signal level.
///
/// The pickup's 1/(1-y) nonlinearity distributes energy across harmonics.
/// For `y = ds·sin(θ)`, the Fourier magnitudes of `y/(1-y)` are:
///   r = (1 - sqrt(1 - ds²)) / ds
///   c_n = 2·r^n / sqrt(1 - ds²)
///
/// Each harmonic passes the pickup HPF differently: `hpf_n = n·f0 / sqrt((n·f0)² + fc²)`.
/// The RMS proxy sums the first 8 harmonics: `sqrt(Σ (c_n · hpf_n)²)`.
///
/// This replaces the old single-harmonic proxy `ds/(1-ds) * f0/sqrt(f0²+fc²)` which
/// used the peak of y/(1-y) instead of Fourier coefficients and ignored H2-H8 energy.
/// The peak/c₁ ratio varies from 1.7 (ds=0.50) to 2.4 (ds=0.80), systematically
/// over-estimating bass by ~2 dB.
///
/// # 2026-09-14: this proxy was always source-shaped; only the corner was wrong
///
/// Note what the maths above actually models: the harmonics of `y/(1-y)`, each
/// then passed through a one-pole high-pass. That is **exactly** the structure
/// of the restructured pickup — a source term carrying the nonlinearity, into a
/// nearly-LTI network (see `pickup.rs`). It was never a model of the
/// *pre-restructure* pickup, which put the nonlinearity in the network's time
/// constant; against that model this proxy was structurally wrong, and nobody
/// noticed because the error was absorbed into `register_trim_db`.
///
/// So the re-derivation for the restructure needed no new algebra — only the
/// corner. Callers must pass `pickup::PICKUP_FC`; the call site previously
/// hardcoded the superseded 2312 Hz.
///
/// Verified against the restructured module over ds ∈ {0.2, 0.4, 0.6, 0.8} ×
/// f0 ∈ {65, 131, 262, 523, 1046} Hz, normalised at ds=0.5 / f0=262:
///
/// | | 65 Hz | 131 Hz | 262 Hz | 523 Hz | 1046 Hz |
/// |---|---|---|---|---|---|
/// | with fc = 2312 (stale) | -0.5 | -0.4 | -0.2 | +0.6 | **+2.5** |
/// | with fc = 2312, ds=0.8 | -0.4 | -0.1 | +0.7 | +2.0 | **+3.9** |
/// | with fc = PICKUP_FC | -0.04 | 0.00 | -0.01 | -0.01 | -0.01 |
/// | with fc = PICKUP_FC, ds=0.8 | +0.03 | 0.00 | +0.07 | +0.09 | +0.12 |
///
/// ±0.12 dB worst case, against a 4.4 dB spread before. That spread was the
/// DS-feedback loop: because `output_scale` normalises by this proxy, a DS
/// change moved the proxy differently from the way it moved the real pickup, so
/// lowering DS *raised* `output_scale` and the chain level did not track DS.
/// Lowering `DS_CLAMP` could therefore RAISE the chord peak.
pub fn pickup_rms_proxy(ds: f64, f0: f64, fc: f64) -> f64 {
    if ds < 1e-10 {
        return 0.0;
    }
    let r = (1.0 - (1.0 - ds * ds).sqrt()) / ds;
    let inv_sqrt = 1.0 / (1.0 - ds * ds).sqrt();
    let mut sum_sq = 0.0;
    let mut r_n = r;
    for n in 1..=8u32 {
        let cn = 2.0 * r_n * inv_sqrt;
        let nf = n as f64 * f0;
        let hpf_n = nf / (nf * nf + fc * fc).sqrt();
        sum_sq += (cn * hpf_n) * (cn * hpf_n);
        r_n *= r;
    }
    sum_sq.sqrt()
}

/// Empirical register trim from Tier 3 render calibration at v=127.
///
/// Corrects the residual imbalance that the multi-harmonic proxy and voicing
/// slope cannot model analytically: preamp Cin coupling cap HPF (~329 Hz),
/// speaker coloration, displacement_scale clamp effects, and mode interaction
/// artifacts. Reference: MIDI 60 (C4) = 0.0 dB.
///
/// Positive = boost (note too quiet), negative = cut (note too loud).
/// Linear interpolation between anchor points; clamped outside range.
pub fn register_trim_db(midi: u8) -> f64 {
    // Calibrated from zero-trim full-chain (t5_rms) renders at v=127 (2026-03-20).
    // Reference: C4 = -44.9 dBFS. Trim = t5_rms(C4) - t5_rms(note).
    // Measured via: preamp-bench calibrate --zero-trim (melange preamp, default)
    // target_db=-35.0, audio taper (vol²), post-speaker gain +10.5 dB
    // Speaker LPF=5500 Hz
    const ANCHORS: [(f64, f64); 13] = [
        (36.0, -1.3), // C2:  -40.6 → -41.9
        (40.0, 0.0),  // E2:  -41.9 → -41.9
        (44.0, -1.3), // G#2: -40.6 → -41.9
        (48.0, 0.7),  // C3:  -42.5 → -41.9
        (52.0, 0.2),  // E3:  -42.1 → -41.9
        (56.0, -1.0), // G#3: -40.8 → -41.9
        (60.0, 0.0),  // C4:  -41.9 (reference)
        (64.0, 0.9),  // E4:  -42.7 → -41.9
        (68.0, 1.2),  // G#4: -43.0 → -41.9
        (72.0, 0.0),  // C5:  -41.9 → -41.9
        (76.0, 1.8),  // E5:  -43.6 → -41.9
        (80.0, 2.4),  // G#5: -44.2 → -41.9
        (84.0, 3.6),  // C6:  -45.5 → -41.9
    ];

    let m = midi as f64;
    if m <= ANCHORS[0].0 {
        return ANCHORS[0].1;
    }
    if m >= ANCHORS[ANCHORS.len() - 1].0 {
        return ANCHORS[ANCHORS.len() - 1].1;
    }
    for i in 0..ANCHORS.len() - 1 {
        let (x0, y0) = ANCHORS[i];
        let (x1, y1) = ANCHORS[i + 1];
        if m <= x1 {
            let t = (m - x0) / (x1 - x0);
            return y0 + t * (y1 - y0);
        }
    }
    0.0
}

/// Post-speaker output gain in dB.
///
/// Models the "mic on speaker" / "DI output" stage that maps physical SPL to
/// DAW-friendly digital levels. With target_db at -35 dBFS, internal levels are
/// circuit-realistic (power amp uses ~5-10% headroom at ff single notes), but
/// the raw speaker output is too quiet for a DAW. This gain compensates without
/// distorting any nonlinear circuit model — it's applied AFTER all analog stages.
///
/// Lowered from +19.5 dB → +14.5 dB on 2026-04-25 after the DI-limiter
/// removal (5fbc4a1, 220a5aa).
///
/// 2026-04-26 (later): sizing lands after the user-volume / circuit-
/// drive DECOUPLING (see FIXED_CIRCUIT_DRIVE below). With drive pinned at
/// 0.25, the amp output peak (chord-ff + tremolo bright) is constant
/// regardless of user volume; PSG is sized so that user_vol=1.0 puts the
/// worst documented case at engine peak ≤ 1.0, and user_vol=0.5 lands
/// near −6 dBFS (chord-ff). Mid-session iterations: was 19.5 dB pre-Apr-25
/// (DI-limiter era), 14.5 dB Apr 25, 10.5 dB Apr 26 (vol²-pre-amp era).
/// Regression-guarded by `engine::tests::test_engine_peak_below_unity_at_vol_1`.
///
/// 2026-07-19: lowered +22.0 → +17.5 dB after the tremolo LDR-divider
/// correction (schematic #203720-S-3). Modeling the vibrato pot as its real
/// 3-terminal divider raised the accurate preamp gain (no-vibrato baseline
/// ~14 dB, was assumed 6 dB; bright-tremolo peak ~16 dB, was 12.1), which
/// pushed the worst-case engine peak from ≤1.0 to 1.63 (+4.2 dB). PSG drops
/// 4.5 dB to restore the vol=1.0 ≤ 1.0 invariant. This is a post-chain level
/// trim only — the circuit correction (hotter, accurate preamp) is preserved;
/// PSG just re-centers the DAW output level as it always has.
///
/// 2026-07-24: lowered +17.5 → +16.8 dB (−0.7 dB) alongside the MLP retrain
/// against the 0.6.0 signal chain (h16_s123). The refreshed per-note
/// `ds_correction` saturates at its 1.2 inference clamp across the chord-ff
/// voicing, nudging the worst-case engine peak to 1.0796; this post-chain trim
/// restores the vol=1.0 ≤ 1.0 invariant (predicted peak 0.996). Output-level
/// re-center only — the retrained corrections are preserved.
///
/// 2026-08-19: lowered +16.8 → +15.5 dB (−1.3 dB). The vol=1.0 invariant
/// turned out to be tremolo-PHASE-FRAGILE: prior sizing measured a cold
/// (un-warmed) engine at one lucky onset phase. On a warmed engine (the
/// production state — the plugin always warm_up()s) with chord onset swept
/// across the tremolo cycle at 2 ms density, peak = 0.997..1.1484 (broad
/// plateau at onset 160–168 ms; see tests/peak_window_probe.rs). The
/// exposure is structural, not a measurement artifact: the ~40 ms attack
/// transient ends well inside a 178 ms tremolo period, freezing onset phase
/// into the envelope — no longer window averages it out. −1.3 dB puts the
/// worst phase at ~0.989 with honest margin. The invariant test now warms
/// the engine and sweeps phases including the plateau.
///
/// 2026-09-13 (b): lowered +14.8 → +8.9 dB (−5.9 dB) for the pickup-network
/// refit. FORCED re-level, flagged as such: correcting the pickup's corner
/// from the superseded 2312 Hz to the drawn network's 880 Hz passes ~+8 dB
/// more bass below 440 Hz, and the chord-ff invariant is bass-dominated, so
/// the warmed worst-phase peak went to 1.9386 — nearly 2x full scale, i.e.
/// real clipping at vol=1.0. −5.9 dB restores it to ~0.98.
///
/// This is OUTPUT LEVEL ONLY — no voicing, no DS, no output_scale. The
/// relative balance (more bass, same treble) is the intended physics change
/// and is left exactly as the circuit produces it. Whether 8.9 dB is the
/// right shipping level is a Phase-3 voicing/listening decision, not this
/// one; this value only restores the vol=1.0 ≤ 1.0 invariant so the suite
/// is honest. Cumulative drop from the pre-revision 15.5 dB is −6.6 dB.
///
/// 2026-09-13 (a): lowered +15.5 → +14.8 dB (−0.7 dB) for the drawn-topology
/// preamp revision. This is a pure re-level, forced by physics upstream: the
/// drawn topology's gain-vs-shunt curve sits ~1.9 dB above the pre-revision
/// one (C-7 spanning R-7+R-8 makes stage 2 a high-gain CE stage), which pushed
/// the warmed worst-phase chord peak to 1.0620 — over the invariant. −0.7 dB
/// restores it. Nothing about the voicing changed; only the output trim.
/// ## 2026-09-14 (Task D): 8.9 → 4.5 dB, chosen from a DS/PSG tradeoff curve
///
/// PSG is a pure output scalar, so for any `DS_AT_C4` the largest PSG that keeps
/// the warmed worst-phase vol=1.0 chord-ff peak inside the 1.02 bound is exact
/// arithmetic, not a search. **THE CURVE — slide along it by ear:**
///
/// | `DS_AT_C4` | chord peak @PSG 8.9 | max PSG | C4 ff H2/H1 | typ-play RMS vs pre-revision | gate-(a) slope |
/// |---|---|---|---|---|---|
/// | 0.73 | 0.9449 | 9.56 | 59.6% | +1.78 dB | +0.55 dB/order |
/// | 0.78 | 1.1581 | 7.80 | 64.9% | +0.82 dB | +1.44 dB/order |
/// | 0.82 | 1.3832 | 6.25 | 69.4% | -0.06 dB | +2.18 dB/order |
/// | **0.85** | **1.6132** | **4.92** | **73.0%** | **-0.88 dB** | **+2.77 dB/order** |
///
/// Shipped at **DS 0.85 / PSG 4.5** — 0.4 dB under the curve's 4.92 ceiling, to
/// leave +0.42 dB of invariant margin (measured peak 0.9721), matching the
/// +0.35 dB margin the 0.980 reference shipped with. Selection rule was
/// "maximise H2 recovery subject to typical-play loudness within ~2 dB of
/// pre-revision"; every row satisfies the loudness constraint, so H2 decides.
///
/// **Raising DS costs almost exactly what it gains**: 0.73 → 0.85 buys +1.76 dB
/// of H2 for -4.64 dB of PSG, netting -2.66 dB of typical-play level. The
/// exchange rate is ~1.5 dB of level per 1 dB of H2.
///
/// ⚠ **There was no spare headroom to reclaim.** The perception that the build
/// leaves ~10 dB unused at max volume is worst-case sizing, not a level deficit:
/// measured before this change, typical play (C4 v64-v110) already sat **+2.06 dB
/// RMS above the pre-revision build**. The gap between a warmed worst-phase
/// chord-ff and a single mf note is ~20 dB and is structural — it was equally
/// true pre-revision. PSG cannot recover it; only a different sizing metric
/// could.
///
/// ⚠ **Gate (a) and the H2 target are mutually exclusive**, crossing at
/// DS ≈ 0.745. The gate compares the harmonic ladder against a corner-only
/// (purely linear) prediction, which implicitly assumes the pre-revision
/// nonlinearity strength — and that nonlinearity died above the corner, which is
/// the defect the restructure fixed. The residual at DS 0.85 is entirely
/// POSITIVE (no shortfall remains anywhere), and the ladder matches a memoryless
/// y/(1-y) at the attack window's effective y. Read as a shortfall detector the
/// gate passes; read as a two-sided bound it fails. Slide to 0.73 if the
/// harmonic tail is too bright by ear — that is the honest disagreement, and the
/// curve above is how to settle it.
pub const POST_SPEAKER_GAIN_DB: f64 = 4.5;

/// Post-speaker output gain as a linear multiplier (10^(POST_SPEAKER_GAIN_DB/20)).
pub const POST_SPEAKER_GAIN: f64 = 1.678_804_018_122_56; // 10^(4.5/20)

/// Fixed circuit-drive level — multiplier applied between preamp output
/// and power amp input. Historically this was `vol²` (3K audio-taper pot,
/// physically faithful per docs/research/output-stage.md §3), but coupling
/// user volume to BJT drive produced an unusable transition: SPICE drive
/// sweep shows THD jumps from 0.034% at Vin=295 mV to 0.228% at 300 mV
/// (rail-clip onset is binary, no graceful middle). Real players sit at
/// vol≈0.1–0.3 (Avenson's 2–7 mV at pot output measurement) where the amp
/// is essentially a linear 69× gain stage anyway.
///
/// 2026-04-26: decoupled drive from user volume. Pin drive at 0.25 — the
/// value previous calibration was already balanced against (= old vol²
/// at vol=0.5). Apply user volume as a linear post-amp multiplier instead.
/// Result: monotonic, predictable, clip-free across the full vol range.
/// Loses: vol-dependent rail-clip character at high vol (was crackle, not
/// music) and crossover-region grit at very low vol (rarely visited in
/// real play). Preserves: every nonlinearity that defines the 200A sound —
/// pickup 1/(1-y) bark, preamp asymmetric clipping, tremolo loop-gain
/// shunt, MLP per-note corrections, rail sag, divergence guard. The BJT
/// solver still runs every sample; it just runs at one operating point.
pub const FIXED_CIRCUIT_DRIVE: f64 = 0.25;

/// Per-note output scaling to balance the keyboard.
///
/// Applied POST-pickup to decouple volume from nonlinear displacement.
/// Three layers of correction:
///   1. Velocity-aware multi-harmonic proxy — models 1/(1-y) harmonics through
///      HPF at the ACTUAL displacement for this velocity, not just peak.
///      At ff, bass gets harmonic energy that passes the 2312 Hz HPF.
///      At pp, the nonlinearity is nearly linear — bass loses that harmonic
///      boost. The proxy accounts for this automatically.
///   2. Voicing slope — gentle treble roll for preamp BW and harmonic content
///   3. Empirical register trim — calibrated from Tier 3 renders at v=127
///
/// Tuning knobs:
///   TARGET_DB — absolute level
///   VOICING_SLOPE — treble balance (dB/semi above C4)
pub fn output_scale(midi: u8, velocity_norm: f64) -> f64 {
    output_scale_with_config(midi, velocity_norm, &CalibrationConfig::default())
}

pub fn output_scale_with_config(midi: u8, velocity_norm: f64, cfg: &CalibrationConfig) -> f64 {
    // The pickup's small-signal corner. Was hardcoded 2312.0 — the superseded
    // corner from the misread input network — which left this proxy
    // mis-normalising by up to 4.4 dB across register and drive, and fighting
    // any DS change (see `pickup_rms_proxy`). Referenced, not copied, so an LCR
    // measurement of C_TOTAL moves it here too.
    let hpf_fc = crate::pickup::PICKUP_FC;

    let ds = pickup_displacement_scale_with_config(midi, cfg);
    let f0 = midi_to_freq(midi);

    // Velocity-aware proxy: compute at the actual displacement that the pickup
    // sees at this velocity. vel_scale reduces reed amplitude, which reduces
    // the input to the 1/(1-y) nonlinearity, which changes the harmonic content
    // that passes the HPF. At ff (vel_scale=1.0) this equals the old behavior.
    let scurve_v = velocity_scurve(velocity_norm);
    let vel_scale = scurve_v.powf(velocity_exponent(midi));
    let vel_scale_c4 = scurve_v.powf(velocity_exponent(60));
    let effective_ds = (ds * vel_scale).max(1e-6);
    let effective_ds_ref = (cfg.ds_at_c4 * vel_scale_c4).max(1e-6);

    let rms = pickup_rms_proxy(effective_ds, f0, hpf_fc);
    let rms_ref = pickup_rms_proxy(effective_ds_ref, midi_to_freq(60), hpf_fc);

    let flat_db = -20.0 * (rms / rms_ref).log10();
    let voicing_db = cfg.voicing_slope * (midi as f64 - 60.0).max(0.0);
    let trim = if cfg.zero_trim {
        0.0
    } else {
        register_trim_db(midi)
    };

    // Velocity-dependent trim blend: at mf (v=80, norm=0.63, blend=0.546)
    // the register trim is partially applied. At ff (v=127, blend=1.0)
    // the full trim applies, preserving the v=127 calibration.
    // Exponent 1.3 gives ~4 dB spread at mf (was 6.0 dB with ^2.0).
    let vel_blend = velocity_norm.powf(1.3);
    let effective_trim = trim * vel_blend;

    f64::powf(
        10.0,
        (cfg.target_db + flat_db + voicing_db + effective_trim) / 20.0,
    )
}

/// Register-dependent velocity exponent for dynamic expression.
///
/// On a real 200A, mid-register notes (C3-C5) have the most dynamic range
/// because the hammer weight and reed stiffness are well-matched. Bass reeds
/// are heavy (compressed dynamics), treble reeds are light (quick saturation).
///
/// The velocity curve is: amplitude = velocity^exponent
///   exponent < 1.0: compressed dynamics (bass, treble)
///   exponent = 1.0: linear
///   exponent > 1.0: expanded dynamics (mid-register)
///
/// sigma=15: the compression onset is gradual across the keyboard —
/// the hammer-reed stiffness ratio changes smoothly, not abruptly.
/// Gives ~18-22 dB mid-register range, ~10-12 dB at extremes.
pub fn velocity_exponent(midi: u8) -> f64 {
    let m = midi as f64;
    // Bell centered at MIDI 62 (D4). Peak 1.7 (expanded mid dynamics), treble
    // edge 1.3. The BASS edge is compressed to ~0.55 (2026-07): a lower exponent
    // raises the reed amplitude at moderate velocity (ff, at scurve=1.0, is
    // unchanged), so the reed drives close to the pickup and the 1/(1−y) bark
    // spikes appear at moderate playing — not only when slammed. The real 200A
    // bass growls when played moderately; the old symmetric 1.3 edge kept the
    // bass too clean until ff. The intentional cost is reduced bass dynamic
    // range — acceptable here (openwurli models circuit authenticity; loudness/
    // dynamics balancing is Vurli's job, per the scope split).
    let center = 62.0;
    let sigma = 15.0;
    let max_exp = 1.7;
    let treble_min = 1.3;
    let bass_min = 0.55;
    let t = f64::exp(-0.5 * ((m - center) / sigma).powi(2));
    let min_exp = if m < center { bass_min } else { treble_min };
    min_exp + t * (max_exp - min_exp)
}

/// Sigmoid velocity shaping — models neoprene foam pad compression curve.
///
/// k=1.5 gives a mild S: pp slightly compressed, mf and ff nearly linear.
/// Neoprene foam pads (Miessner US 2,932,231) have a more linear compression
/// curve than piano felt. Used by both voice.rs (reed amplitude scaling) and
/// output_scale (velocity-aware pickup RMS proxy).
pub fn velocity_scurve(velocity: f64) -> f64 {
    let k = 1.5;
    let s = 1.0 / (1.0 + (-k * (velocity - 0.5)).exp());
    let s0 = 1.0 / (1.0 + (k * 0.5).exp());
    let s1 = 1.0 / (1.0 + (-k * 0.5).exp());
    (s - s0) / (s1 - s0)
}

/// Full parameter set for one note.
pub struct NoteParams {
    pub fundamental_hz: f64,
    pub mode_ratios: [f64; NUM_MODES],
    pub mode_amplitudes: [f64; NUM_MODES],
    pub mode_decay_rates: [f64; NUM_MODES],
}

// ─── Intermodulation risk detection ─────────────────────────────────────────

/// Per-mode intermodulation product analysis.
pub struct IntermodProduct {
    pub mode: usize,
    pub mode_ratio: f64,
    pub nearest_integer: u32,
    pub fractional_offset: f64,
    pub beat_hz: f64,
    pub effective_amplitude: f64,
    pub perceptual_weight: f64,
    pub risk_score: f64,
}

/// Per-note intermodulation risk summary.
pub struct IntermodReport {
    pub midi: u8,
    pub fundamental_hz: f64,
    pub mu: f64,
    pub products: Vec<IntermodProduct>,
    pub max_risk: f64,
    pub total_risk: f64,
}

/// Psychoacoustic weighting for audible beating.
///
/// Peak (1.0) at 5-10 Hz (worst audible beating), ramps up from 0.5-2 Hz,
/// decays 15-40 Hz, floor at 0.1 above 40 Hz, zero below 0.5 Hz.
pub fn perceptual_beat_weight(beat_hz: f64) -> f64 {
    if beat_hz < 0.5 {
        return 0.0;
    }
    if beat_hz < 2.0 {
        // Ramp from 0 at 0.5 Hz to ~0.5 at 2 Hz
        return 0.5 * (beat_hz - 0.5) / 1.5;
    }
    if beat_hz <= 5.0 {
        // Ramp from 0.5 at 2 Hz to 1.0 at 5 Hz
        return 0.5 + 0.5 * (beat_hz - 2.0) / 3.0;
    }
    if beat_hz <= 10.0 {
        // Plateau at 1.0
        return 1.0;
    }
    if beat_hz <= 40.0 {
        // Decay from 1.0 at 10 Hz to 0.1 at 40 Hz
        return 0.1 + 0.9 * (40.0 - beat_hz) / 30.0;
    }
    // Floor above 40 Hz
    0.1
}

/// Dwell attenuation at ff velocity (velocity=1.0), inlined to keep tables.rs
/// dependency-free from hammer.rs.
///
/// Uses Miessner patent dwell: 0.75 cycles at ff.
fn dwell_attenuation_ff(fundamental_hz: f64, mode_ratios: &[f64; NUM_MODES]) -> [f64; NUM_MODES] {
    let t_dwell = (0.75 / fundamental_hz).clamp(0.0003, 0.020);
    let sigma_sq = 8.0 * 8.0;

    let mut atten: [f64; NUM_MODES] = std::array::from_fn(|i| {
        let ft = fundamental_hz * mode_ratios[i] * t_dwell;
        (-ft * ft / (2.0 * sigma_sq)).exp()
    });

    let a0 = atten[0];
    if a0 > 1e-30 {
        for a in &mut atten {
            *a /= a0;
        }
    }
    atten
}

/// Compute intermodulation risk for a given MIDI note.
///
/// For each mode 2-7, measures how close its frequency ratio is to the nearest
/// integer harmonic. When the pickup's 1/(1-y) nonlinearity generates intermod
/// products between inharmonic modes, they land near (but not at) integer
/// harmonics, producing audible beating in the 3-15 Hz range.
pub fn intermod_risk(midi: u8) -> IntermodReport {
    let fundamental_hz = midi_to_freq(midi);
    let mu = tip_mass_ratio(midi);
    let ratios = mode_ratios(mu);
    let dwell = dwell_attenuation_ff(fundamental_hz, &ratios);

    let mut products = Vec::new();
    let mut max_risk = 0.0f64;
    let mut total_risk = 0.0f64;

    let coupling = spatial_coupling_coefficients(mu, reed_length_mm(midi));

    // Modes 2-7 (index 1-6) — mode 1 is always ratio 1.0, no intermod
    // NOTE: hammer_spatial_coupling not applied — OBM amplitudes already include it
    for i in 1..NUM_MODES {
        let ratio = ratios[i];
        let nearest = ratio.round() as u32;
        let fractional_offset = (ratio - nearest as f64).abs();
        let beat_hz = fractional_offset * fundamental_hz;
        let effective_amplitude = BASE_MODE_AMPLITUDES[i] * coupling[i] * dwell[i];
        let weight = perceptual_beat_weight(beat_hz);
        let risk = effective_amplitude * weight;

        max_risk = max_risk.max(risk);
        total_risk += risk;

        products.push(IntermodProduct {
            mode: i + 1, // 1-indexed for display
            mode_ratio: ratio,
            nearest_integer: nearest,
            fractional_offset,
            beat_hz,
            effective_amplitude,
            perceptual_weight: weight,
            risk_score: risk,
        });
    }

    IntermodReport {
        midi,
        fundamental_hz,
        mu,
        products,
        max_risk,
        total_risk,
    }
}

/// Compute all parameters for a given MIDI note.
pub fn note_params(midi: u8) -> NoteParams {
    let fundamental_hz = midi_to_freq(midi);
    let mu = tip_mass_ratio(midi);
    let ratios = mode_ratios(mu);
    let decay_rates = mode_decay_rates(midi, &ratios);

    let mut amplitudes = BASE_MODE_AMPLITUDES;

    // NOTE: hammer_spatial_coupling is NOT applied here because
    // BASE_MODE_AMPLITUDES were calibrated from OBM recordings that already
    // include the real hammer's excitation profile. Applying spatial coupling
    // on top would double-count, boosting inharmonic modes 2-3 by +11-14 dB
    // and creating a metallic "plink" on attack.

    // Apply spatial pickup coupling — finite plate length attenuates higher bending modes
    let coupling = spatial_coupling_coefficients(mu, reed_length_mm(midi));
    for (amp, &k) in amplitudes.iter_mut().zip(coupling.iter()) {
        *amp *= k;
    }

    NoteParams {
        fundamental_hz,
        mode_ratios: ratios,
        mode_amplitudes: amplitudes,
        mode_decay_rates: decay_rates,
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_midi_to_freq() {
        assert!((midi_to_freq(69) - 440.0).abs() < 0.01);
        assert!((midi_to_freq(60) - 261.63).abs() < 0.1);
        assert!((midi_to_freq(33) - 55.0).abs() < 0.1);
    }

    #[test]
    fn test_mode_ratios_bare_beam() {
        let r = mode_ratios(0.0);
        assert!((r[0] - 1.0).abs() < 1e-6);
        assert!((r[1] - 6.267).abs() < 0.01);
        assert!((r[2] - 17.547).abs() < 0.02);
    }

    #[test]
    fn test_mode_ratios_with_tip_mass() {
        let r = mode_ratios(0.10);
        assert!((r[1] - 7.13).abs() < 0.05);
    }

    #[test]
    fn test_tip_mass_ratio_range() {
        assert!(tip_mass_ratio(33) > 0.05);
        assert!(tip_mass_ratio(57) < 0.02);
    }

    #[test]
    fn test_decay_rate_increases_with_pitch() {
        assert!(fundamental_decay_rate(60) > fundamental_decay_rate(48));
        assert!(fundamental_decay_rate(84) > fundamental_decay_rate(72));
    }

    #[test]
    fn test_decay_rate_obm_calibration() {
        // OBM-calibrated frequency power law: decay = 0.005 * f^1.22
        // Wide bounds accommodate ±30% OBM scatter while catching regressions.
        let bass = fundamental_decay_rate(36); // C2
        assert!(
            (bass - 3.0).abs() < 0.5,
            "C2 should be near floor (3.0), got {bass:.1}"
        );

        // Mid/treble: frequency power law gives gentler curve than old MIDI law
        let c4 = fundamental_decay_rate(60); // ~4.5 dB/s
        let c5 = fundamental_decay_rate(72); // ~10.3 dB/s
        let c6 = fundamental_decay_rate(84); // ~24.2 dB/s
        assert!(
            c4 > 3.5 && c4 < 7.0,
            "C4 decay should be ~4.5 dB/s, got {c4:.1}"
        );
        assert!(
            c5 > 7.0 && c5 < 16.0,
            "C5 decay should be ~10.3 dB/s, got {c5:.1}"
        );
        assert!(
            c6 > 17.0 && c6 < 35.0,
            "C6 decay should be ~24.2 dB/s, got {c6:.1}"
        );
    }

    #[test]
    fn test_intermod_risk_below_threshold() {
        // Regression guard: no note in the playable range should exceed this threshold.
        // If this fails, it means mode decay or bass taper changed in a way that
        // reintroduces audible beating from inharmonic intermod products.
        //
        // The static metric captures worst-case ff attack amplitude before temporal
        // decay kicks in. Bass notes (MIDI 33-47) have the highest risk due to
        // high tip mass ratios making mode 2 inharmonic. The p=1.5 mode decay
        // ensures intermod is attack-only; render mode verifies spectral cleanliness.
        //
        // Find actual worst case first, then assert with headroom.
        let mut worst_risk = 0.0f64;
        let mut worst_midi = 0u8;
        for midi in MIDI_LO..=MIDI_HI {
            let report = intermod_risk(midi);
            if report.max_risk > worst_risk {
                worst_risk = report.max_risk;
                worst_midi = midi;
            }
        }
        // Threshold = 1.25x the current worst case, providing headroom for minor
        // parameter adjustments while catching any major regression.
        let threshold = worst_risk * 1.25;
        assert!(
            threshold < 0.15,
            "Worst-case risk at MIDI {} is {:.4} — threshold {:.4} seems too high, investigate",
            worst_midi,
            worst_risk,
            threshold
        );
        for midi in MIDI_LO..=MIDI_HI {
            let report = intermod_risk(midi);
            assert!(
                report.max_risk < threshold,
                "MIDI {} ({:.1} Hz): max_risk = {:.4} exceeds {:.4}",
                midi,
                report.fundamental_hz,
                report.max_risk,
                threshold
            );
        }
    }

    #[test]
    fn test_intermod_risk_known_values() {
        // A1 (MIDI 33): mu=0.10, mode 2 ratio ~7.13
        let report = intermod_risk(33);
        let m2 = &report.products[0]; // mode 2 is first in products vec
        assert_eq!(m2.mode, 2);
        assert!(
            (m2.mode_ratio - 7.13).abs() < 0.1,
            "mode 2 ratio = {}",
            m2.mode_ratio
        );
        assert_eq!(m2.nearest_integer, 7);
        // Beat frequency = fractional_offset * fundamental_hz
        // A1 = 55 Hz, offset ~0.13, beat ~7.2 Hz
        assert!(
            m2.beat_hz > 3.0 && m2.beat_hz < 12.0,
            "A1 mode 2 beat_hz = {}",
            m2.beat_hz
        );
        // Should be in the high perceptual weight zone (5-10 Hz)
        assert!(
            m2.perceptual_weight > 0.8,
            "A1 mode 2 perceptual_weight = {}",
            m2.perceptual_weight
        );
    }

    #[test]
    fn test_perceptual_beat_weight_shape() {
        // Sub-1 Hz: near zero (below audible beating)
        assert!(perceptual_beat_weight(0.3) < 0.01);
        // 7 Hz: in the peak zone (5-10 Hz)
        assert!(perceptual_beat_weight(7.0) > 0.9);
        // 50 Hz: well above beating range, should be at floor
        assert!(perceptual_beat_weight(50.0) < 0.2);
    }

    // ─── Spatial pickup coupling tests ──────────────────────────────────────

    #[test]
    fn test_reed_length_known_values() {
        // Reed 1 (MIDI 33): n=1, bass formula: 3.0 - 1/20 = 2.95 in = 74.93 mm
        let l1 = reed_length_mm(33);
        assert!((l1 - 74.93).abs() < 0.1, "reed 1 length = {l1}");
        // Reed 64 (MIDI 96): n=64, treble formula: 2.0 - 44/44 = 1.0 in = 25.4 mm
        let l64 = reed_length_mm(96);
        assert!((l64 - 25.4).abs() < 0.1, "reed 64 length = {l64}");
        // Reed 20 (MIDI 52): n=20, bass formula: 3.0 - 20/20 = 2.0 in = 50.8 mm
        let l20 = reed_length_mm(52);
        assert!((l20 - 50.8).abs() < 0.1, "reed 20 length = {l20}");
    }

    #[test]
    fn test_mode_shape_tip_nonzero() {
        // |phi_n(1.0)| should be significantly nonzero for all modes.
        // Higher modes can have negative tip displacement — the sign alternates.
        for &mu in &[0.0, 0.05, 0.10, 0.20, 0.50] {
            let betas = eigenvalues(mu);
            for (i, &beta) in betas.iter().enumerate() {
                let tip = mode_shape(beta, 1.0);
                assert!(
                    tip.abs() > 0.1,
                    "mode_shape(beta={beta:.4}, 1.0) = {tip:.6} for mu={mu}, mode {i}"
                );
            }
        }
    }

    #[test]
    fn test_mode_shape_clamp_zero() {
        // phi_n(0.0) should be ~0 for all modes (clamped end)
        for &mu in &[0.0, 0.10, 0.50] {
            let betas = eigenvalues(mu);
            for (i, &beta) in betas.iter().enumerate() {
                let clamp = mode_shape(beta, 0.0);
                assert!(
                    clamp.abs() < 1e-10,
                    "mode_shape(beta={beta:.4}, 0.0) = {clamp:.2e} for mu={mu}, mode {i}"
                );
            }
        }
    }

    #[test]
    fn test_coupling_mode1_is_unity() {
        // After normalization, mode 1 coupling is always exactly 1.0.
        // The absolute kappa_1 (0.83–0.94) is absorbed into displacement_scale.
        for midi in (MIDI_LO..=MIDI_HI).step_by(4) {
            let mu = tip_mass_ratio(midi);
            let len = reed_length_mm(midi);
            let kappa = spatial_coupling_coefficients(mu, len);
            assert!(
                (kappa[0] - 1.0).abs() < 1e-10,
                "MIDI {midi}: kappa_1 = {:.10} (expected exactly 1.0)",
                kappa[0]
            );
        }
    }

    #[test]
    fn test_coupling_decreases_with_mode() {
        // Coupling generally decreases with mode number, but strict monotonicity
        // is NOT guaranteed — the spatial integration behaves like a sinc function
        // with side lobes, so occasionally a higher mode's spatial pattern aligns
        // better with the pickup window. What matters:
        //   1. Mode 1 always has the highest coupling
        //   2. Mode 2 is always less than mode 1
        //   3. Higher modes are all below mode 1
        for midi in (MIDI_LO..=MIDI_HI).step_by(4) {
            let mu = tip_mass_ratio(midi);
            let len = reed_length_mm(midi);
            let kappa = spatial_coupling_coefficients(mu, len);

            // Mode 1 has the highest coupling
            for i in 1..NUM_MODES {
                assert!(
                    kappa[i] <= kappa[0] + 1e-6,
                    "MIDI {midi}: kappa[{i}]={:.4} > kappa[0]={:.4}",
                    kappa[i],
                    kappa[0]
                );
            }
            // Mode 2 is less than mode 1 (first spatial attenuation step)
            assert!(
                kappa[1] < kappa[0],
                "MIDI {midi}: kappa[1]={:.4} >= kappa[0]={:.4}",
                kappa[1],
                kappa[0]
            );
        }
    }

    #[test]
    fn test_coupling_register_variation() {
        // Treble reeds (shorter, larger ell/L) should have more suppression
        // than bass reeds (longer, smaller ell/L) for the same mode
        let mu_bass = tip_mass_ratio(33); // A1 — longest reed
        let mu_treb = tip_mass_ratio(96); // C7 — shortest reed
        let kappa_bass = spatial_coupling_coefficients(mu_bass, reed_length_mm(33));
        let kappa_treb = spatial_coupling_coefficients(mu_treb, reed_length_mm(96));

        // For mode 3+ the treble should be more suppressed (smaller kappa)
        // due to larger ell/L overlap
        for i in 2..NUM_MODES {
            assert!(
                kappa_treb[i] < kappa_bass[i],
                "Mode {}: treble kappa {:.4} should be < bass kappa {:.4}",
                i + 1,
                kappa_treb[i],
                kappa_bass[i]
            );
        }
    }

    #[test]
    fn test_eigenvalues_matches_mode_ratios() {
        // Verify that the eigenvalues() refactor produces identical mode_ratios
        for &mu in &[0.0, 0.01, 0.05, 0.10, 0.15, 0.20, 0.30, 0.50] {
            let betas = eigenvalues(mu);
            let ratios = mode_ratios(mu);
            let b1_sq = betas[0] * betas[0];
            for i in 0..NUM_MODES {
                let ratio_from_beta = (betas[i] * betas[i]) / b1_sq;
                assert!(
                    (ratio_from_beta - ratios[i]).abs() < 1e-10,
                    "mu={mu}, mode {i}: eigenvalue ratio {ratio_from_beta} != mode_ratios {:.10}",
                    ratios[i]
                );
            }
        }
    }

    // ─── Reed compliance and displacement scale tests ────────────────────

    #[test]
    fn test_blank_dims_known_values() {
        // Reed 1 (MIDI 33): blank 1, w=0.151", t=0.026" (200A)
        let (w, t) = reed_blank_dims(33);
        assert!((w - 0.151 * 25.4).abs() < 0.01, "MIDI 33 width = {w}");
        assert!((t - 0.026 * 25.4).abs() < 0.01, "MIDI 33 thickness = {t}");

        // Reed 42 (MIDI 74): blank 3, w=0.121", t=0.034" (200A)
        let (w, t) = reed_blank_dims(74);
        assert!((w - 0.121 * 25.4).abs() < 0.01, "MIDI 74 width = {w}");
        assert!((t - 0.034 * 25.4).abs() < 0.01, "MIDI 74 thickness = {t}");

        // Reed 64 (MIDI 96): blank 5, w=0.098", t=0.034" (200A)
        let (w, t) = reed_blank_dims(96);
        assert!((w - 0.098 * 25.4).abs() < 0.01, "MIDI 96 width = {w}");
        assert!((t - 0.034 * 25.4).abs() < 0.01, "MIDI 96 thickness = {t}");
    }

    #[test]
    fn test_blank_dims_smooth_transition() {
        // The thickness transition from bass (0.026") to mid (0.034") should be
        // smooth over MIDI 48-58 (reeds 16-26), not a sharp step.
        let (_, t48) = reed_blank_dims(48); // reed 16: pure bass
        let (_, t53) = reed_blank_dims(53); // reed 21: mid-transition
        let (_, t58) = reed_blank_dims(58); // reed 26: pure mid

        assert!(
            (t48 - 0.026 * 25.4).abs() < 0.01,
            "MIDI 48 should be pure bass (200A: 0.026\")"
        );
        assert!(
            (t58 - 0.034 * 25.4).abs() < 0.01,
            "MIDI 58 should be pure mid (200A: 0.034\")"
        );
        // Mid-transition should be between
        assert!(
            t53 > t48 + 0.02 && t53 < t58 - 0.02,
            "MIDI 53 thickness ({t53:.3}) should be between {t48:.3} and {t58:.3}"
        );
    }

    #[test]
    fn test_compliance_bass_greater_than_treble() {
        // Bass reeds (long, thin) have much higher compliance than treble (short, thick)
        let c_bass = reed_compliance(33); // A1
        let c_mid = reed_compliance(60); // C4
        let c_treb = reed_compliance(96); // C7

        assert!(
            c_bass > c_mid * 5.0,
            "Bass compliance ({c_bass:.0}) should be >5x mid ({c_mid:.0})"
        );
        assert!(
            c_mid > c_treb * 2.0,
            "Mid compliance ({c_mid:.0}) should be >2x treble ({c_treb:.0})"
        );
    }

    #[test]
    fn test_displacement_scale_monotone_decreasing() {
        // Displacement scale should generally decrease from bass to treble
        // (more compliance → more deflection → more bark)
        // Bass notes may clamp at DS_CLAMP upper bound, so use >= for bass vs mid.
        let ds_33 = pickup_displacement_scale(33); // A1
        let ds_60 = pickup_displacement_scale(60); // C4
        let ds_96 = pickup_displacement_scale(96); // C7

        assert!(
            ds_33 >= ds_60,
            "A1 ({ds_33:.3}) should have >= bark than C4 ({ds_60:.3})"
        );
        assert!(
            ds_60 > ds_96,
            "C4 ({ds_60:.3}) should have more bark than C7 ({ds_96:.3})"
        );
    }

    #[test]
    fn test_displacement_scale_c4_calibration() {
        // C4 is the reference point — should be exactly DS_AT_C4
        let ds = pickup_displacement_scale(60);
        assert!(
            (ds - DS_AT_C4).abs() < 0.001,
            "C4 displacement scale = {ds:.4}, expected {DS_AT_C4}"
        );
    }

    #[test]
    fn test_displacement_scale_range() {
        // Bass should be high (strong bark), treble should be low (clean)
        let ds_bass = pickup_displacement_scale(33);
        let ds_treb = pickup_displacement_scale(96);

        assert!(
            ds_bass > 0.50,
            "Bass ds ({ds_bass:.3}) should give strong bark"
        );
        assert!(
            ds_treb < 0.35,
            "Treble ds ({ds_treb:.3}) should be nearly clean"
        );
        // Ratio should be at least 2.5:1 (bass is barkier, but clamp compresses range)
        assert!(
            ds_bass / ds_treb > 2.5,
            "Bass/treble ratio = {:.1}x, expected >2.5x",
            ds_bass / ds_treb
        );
    }
}
