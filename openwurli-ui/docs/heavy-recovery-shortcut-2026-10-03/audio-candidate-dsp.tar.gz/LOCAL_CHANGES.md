Vendored from https://github.com/Ferglerz/openwurli at b51f8dad3c5fb62070a20a11e20bf2886b8ff860 (openwurli-dsp 0.7.0).

Local changes: standalone manifest metadata; explicit full-MIDI note-on and note-off entry points in engine.rs. Original clamped entry points remain compatible. The UI owns range selection; extended note-off remains available after disabling the toggle so held notes can release.
